#include "bdd.h"
#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <string>
#include <cstring>
#include <cstdlib>
#include "time.h"
#include <map>
#include "windows.h"
#include "psapi.h"

static bool g_verbose = false;
static unsigned g_num_rules = 0;
static unsigned g_num_routers = 0;
static bool g_reverse = false;

#define IF_VERBOSE(_cmd_) if (g_verbose) { _cmd_; }
#define IFN_VERBOSE(_cmd_) if (!g_verbose) { _cmd_; }

void read_nums(std::istream& is, unsigned & x, unsigned& y) {
    x = 0; y = 0;
    is >> x;
    is >> y;
    std::string line;
    std::getline(is, line);
}

void print_stats() {
    bddStat stats;
    bdd_stats(stats);
    std::cout << "num nodes:   " << stats.nodenum << "\n";
    std::cout << "produced:    " << stats.produced << "\n";
    std::cout << "freenodes:   " << stats.freenodes << "\n";
    std::cout << "varnum:      " << stats.varnum << "\n";
    std::cout << "minfreenodes " << stats.minfreenodes << "\n";
    std::cout << "gbcnum       " << stats.gbcnum << "\n";
    std::cout << "cachesize    " << stats.cachesize << "\n";
}

void print_map(std::map<int,bdd> const& APs) {
    std::cout << "Atomic predicates:\n";
    std::map<int, bdd>::const_iterator it = APs.begin(), end = APs.end();
    for (; it != end; ++it) {
        std::cout << it->second << "\n";
    }    
}

void check_is_partition(std::map<int,bdd> const& APs) {
    std::map<int, bdd>::const_iterator it = APs.begin(), end = APs.end();
    bdd S = bdd_false();
    unsigned i = 0;
    for (; it != end; ++it) {
        bdd p = it->second;
        bdd r = p & S;
        if (r != bdd_false()) {
            std::cout << "Non-disjoint: " << i << "\n";
            exit(0);
            return;
        }
        S |= p;
        ++i;
    }
    if (S != bdd_true()) {
        std::cout << "Partial partition\n";
    }
}

void insert1(bdd p, std::map<int,bdd>& APs, std::map<int,bdd>& newAPs) {
    newAPs.clear();
    bdd zero = bdd_false();
    std::map<int, bdd>::iterator it = APs.begin(), end = APs.end();
    IF_VERBOSE(std::cout << "Inserting " << p << "\n");
    for (; it != end; ++it) {
        if (p == zero) {
            IF_VERBOSE(std::cout << "re-insert: " << it->second << "\n");
            newAPs.insert(*it);
            continue;
        }
        bdd p1 = p & it->second;
        if (p1 == zero) {
            IF_VERBOSE(std::cout << "re-insert: " << it->second << "\n");
            newAPs.insert(*it);
        }
        else {
            IF_VERBOSE(std::cout << "insert: " << p1 << "\n");
            newAPs.insert(std::make_pair(p1.id(), p1));
            bdd p2 = (!p) & it->second;
            if (p2 != zero) {
                if (g_verbose) {
                    std::cout << "insert: " << p2 << "\n";
                }
                newAPs.insert(std::make_pair(p2.id(), p2));
            }
            p &= !it->second;
            IF_VERBOSE(std::cout << "updated: " << p << "\n");
        }
    }
    IF_VERBOSE(print_map(newAPs));
}

void insert2(bdd p, std::map<int,bdd>& APs, std::map<int,bdd>& newAPs) {
    newAPs.clear();
    bdd zero = bdd_false();
    std::map<int, bdd>::iterator it = APs.begin(), end = APs.end();
    for (; it != end && p != zero; ++it) {
        bdd p1 = p & it->second;
        if (p1 == zero) {
            newAPs.insert(*it);
        }
        else {
            newAPs.insert(std::make_pair(p1.id(), p1));
            bdd p2 = !p & it->second;
            if (p2 != zero) {
                newAPs.insert(std::make_pair(p2.id(), p2));
            }            
        }
    }
}



void routers_bdd(bool use_insert1, char const *file) {
    std::ifstream is(file);
    if (is.bad() || is.fail()) {
        std::cout << "could not load " << file << "\n";
        exit(0);
    }

    double start_time = static_cast<double>(clock());

    bdd_init(1000, 10000);
    bdd one = bdd_true();
    bdd zero = bdd_false();

    std::string line;
    unsigned W, M;
    read_nums(is, W, M);
    bdd_setvarnum(W);
    std::vector<bdd> lits;
    for (unsigned i = 0; i < W; ++i) {
        if (g_reverse) {
            lits.push_back(bdd_ithvarpp(W-i-1));
        }
        else {
            lits.push_back(bdd_ithvarpp(i));
        }
    }

    g_num_routers = M;
    std::map<int, bdd> predicates;
    for (unsigned r = 0; r < M; ++r) {
        unsigned P, K;
        std::vector<bdd> pred;
        read_nums(is, K, P);
        // std::cout << K << " " << P << "\n";
        // add P+1 ports (one for drop)
        for (unsigned i = 0; i <= P; ++i) {
            pred.push_back(zero);
        }
        bdd fwd = zero;
        unsigned p;
        for (unsigned g = 0; g < K; ++g) {
            ++g_num_rules;
            bdd prefix = one;
            is >> p;
            std::getline(is, line);
            char const* chars = line.c_str();
            unsigned i = 0;
            //std::cout << g << " " << p << " : " << line << "\n";
            //std::cout.flush();
            while (*chars) {
                if (*chars == 'x') ++i;
                if (*chars == '*') ++i;
                else if (*chars == '1') prefix = prefix & lits[i++];
                else if (*chars == '0') prefix = prefix & !lits[i++];                
                else if (*chars == '#') break;
                ++chars;
            }
            if (p >= pred.size()) {
                std::cout << "port number " << p << " too big " << P << "\n";
                exit(0);
            }
            pred[p] = pred[p] | (prefix & !fwd);
            fwd = fwd | prefix;
            if (p == 0 && i == 0) break;
        }
        pred[P] = pred[P] | !fwd;
        for (unsigned i = 0; i < pred.size(); ++i) {            
            predicates.insert(std::make_pair(pred[i].id(), pred[i]));
        }
    }

    std::map<int,bdd> APs, newAPs;
    APs.insert(std::make_pair(one.id(), one));
    
    std::cout << "Processing predicates " << predicates.size() << "\n";
    std::cout.flush();
    std::map<int, bdd>::iterator it = predicates.begin(), end = predicates.end();
    for (; it != end; ++it) {
        IF_VERBOSE(print_map(APs));
        IFN_VERBOSE(std::cout << "."; std::cout.flush(););
        
        bdd p = it->second;
        if (p == zero) {
            continue;
        }
        if (p == one) {
            continue;
        }
        if (use_insert1) {
            insert1(p, APs, newAPs);
        }
        else {
            insert2(p, APs, newAPs);
        }
        APs.clear();
        APs = newAPs;
        if (g_verbose) {
            check_is_partition(APs);
        }
    }
    std::cout << file << "\n";
    std::cout << "\nNew predicates: " << APs.size() << "\n";
    double end_time = static_cast<double>(clock());
    std::cout << (end_time - start_time)/CLOCKS_PER_SEC << " seconds\n";
    print_stats();
    std::cout << "num routers: " << g_num_routers << "\n";
    std::cout << "num rules:   " << g_num_rules << "\n";
    std::cout.flush();

    PROCESS_MEMORY_COUNTERS info;
    GetProcessMemoryInfo(GetCurrentProcess(), &info, 0);
    std::cout << "peak memory usage: " << static_cast<double>(info.PeakWorkingSetSize)/1000000.0 << " MB\n";

    IF_VERBOSE(print_map(APs));
}




int main(int argc, char ** argv) {

    //std::cout << "num args: " << argc << "\n";
    //for (unsigned i = 0; i < argc; ++i) {
    //    std::cout << argv[i] << "\n";
    //}
    std::cout.flush();
    bool use_insert1 = true;
    if (argc == 3 && std::string(argv[2]) == "2") {
        use_insert1 = false;
    }
    if (argc == 3 && std::string(argv[2]) == "v") {
        g_verbose = true;
    }
    if (argc >= 2) {
        routers_bdd(use_insert1, argv[1]);
    }
    return 0;
}
