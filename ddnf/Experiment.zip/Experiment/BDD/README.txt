First install the PerlDD package.

$ cd PerlDD
$ perl Makefile.PL
$ make install

You can check whether it work with

$ perl test.pl

Now, try router.pl

$ cd ..
$ perl router.pl < rules.net

It computes and prints atomic predicates from forwarding tables using BDDs. The
format of the forwarding tables is explained in rules.net. For each router,
rules have to be in most specific to least specific order.
