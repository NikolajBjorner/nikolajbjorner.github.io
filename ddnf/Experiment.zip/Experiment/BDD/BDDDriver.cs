﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace DNALib
{

    public class BDDDriver
    {
        public BDDDriver()
        {
        }

        public string PrintMask(AddressMask am)
        {
            StringBuilder sb = new StringBuilder();                        
            for(int i = 31; i > 31 - (int)am.mask; --i)
            {
                if (0 != (0x1 & (am.address >> i)))
                {
                    sb.Append("1");
                }
                else
                {
                    sb.Append("0");
                }
            }
            return sb.ToString();            
        }

        public void Q10Query(Q10Network network, string src = null, AddressMask dst = null)
        {
            Stopwatch sw = new Stopwatch();
            if (Logger.vl >= 0)
            {
                Logger.Log("Starting to generate guards");
            }
            sw.Start();

            // hops are just globally unique identifiers
            // maybe relate them to identifiers of routers?

            Console.WriteLine("32 {0}", network.name2router.Count);
            foreach (var kv in network.name2router)
            {
                string routerName = kv.Key;
                Router router = kv.Value;                
                if (router.rules.Count == 0) { continue; }
                var sortedRules = router.rules.OrderBy(rl => rl.addressMask.mask).Reverse();
                var hops = router.rules.SelectMany(rl => rl.NextHops).Distinct();
                var hop2id = new Dictionary<NextHop, int>();
                var count = 0;
                foreach (var hop in hops)
                {
                    if (!hop2id.ContainsKey(hop))
                        hop2id.Add(hop, count++);
                }

                Console.WriteLine("{0} {1} # {2}", router.rules.Count, hops.Count(), routerName);

                foreach (Rule rule in sortedRules)
                {
                    foreach (var hop in rule.NextHops)
                    {
                        Console.WriteLine("{0} {1} # {2}", hop2id[hop], PrintMask(rule.addressMask), rule.addressMask);
                        break; // skip the rest, not clear if experiment needs this
                    }			        		            
                }
            }
        }


    }
}
