#!/usr/bin/perl -w
#/usr/local/perl-5.10.1/bin/perl -w


######################### We start with some black magic to print on failure.
# From PerlDD-0.09::test.pl
# Thanks to Fabio Somenzi and Bryan Brady
#
# Author: Garvit Juniwal
########################

BEGIN {print "Atomic Predicates BDD experiment\n";}
END 
{
    print "Error loading Cudd!\n" unless $cudd_loaded;
}

use Cudd;
use Time::HiRes;
$cudd_loaded = 1;
######################### End of black magic.

sub routers {
    my $manager = new Cudd;
    
    # Create logical one and zero
    my $one = $manager->BddOne;
    my $zero = Not $one;

    chomp(my $line = <>); # bit-width
    my @tokens = split(' ', $line);
    my $W = $tokens[1]; # bit-width
    my $M = $tokens[0]; # number of rulesets
    my @lits;
    for($i = 0; $i < $W; $i++) {
        push(@lits, $manager->BddVar);
    }

    my @predicates;
    my $num_rules = 0;
    for($r = 0; $r < $M; $r++) {
        # read a ruleset
        chomp($line = <>);
        @tokens = split(' ', $line);
        my $P = $tokens[0]; # number of output port
        my $K = $tokens[1]; # number of rules, assuming most specific first
        $num_rules += $K;
        my %pred_map;
        my $fwd = $zero;
        my $max = 40000;
        my $count = 0;
        %pred_map = (); # clear the map
        for($g = 0; $g < $K - 1; $g++) {
            chomp($line = <>);
            $count++;
            if ($count > $max) {
                next;
            }
            @tokens = split(' ', $line);
            my $p = $tokens[0];
            my $bv = $tokens[1];
            my @bits = split('', $bv);
            my $prefix = $one;
            for ($ii = 0; $ii < @bits; $ii++) {
                my $c = $bits[$ii];
                if ($c eq "0") {
                    $prefix = $prefix * !$lits[$ii];
                } elsif ($c eq "1") {
                    $prefix = $prefix * $lits[$ii];
                }
            }
            if (!exists $pred_map{$p}) {
                $pred_map{$p} = $zero;
            }
            $pred_map{$p} = $pred_map{$p} + ($prefix * !$fwd);
            $fwd = $fwd + $prefix;
        }
        $line = <>; # hack to ignore hte 0.0.0.0/0 rule
        $pred_map{$P} = !$fwd;

        foreach my $val (values %pred_map) {
            push(@predicates, $val);
        }
    }

    my @APs = ($one);
    foreach $pred (@predicates) {
        my @newAPs;
        foreach $ap (@APs) {
            my @splitap = ($ap * $pred, $ap * !$pred);
            foreach $newap (@splitap) {
                if ($newap != $zero) {
                    push(@newAPs, $newap);
                }
            }
        }
        @APs = @newAPs;
    }

    my $numAP = @APs;
    print "Printing  first 10 out of $numAP Atomic Predicates found from $num_rules rules\n";
    my $count = 0;
    foreach $ap (@APs) {
        if ($count >= 10) {
            last;
        }
        $ap->Print($W, 2);
        $count++;
    }
}



################################################################################
# Main                                                                         #
################################################################################
 
# Call appropriate function
routers();
