﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MicrosoftResearch.Infer;
using MicrosoftResearch.Infer.Distributions;
using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer.Maths;
using System.Diagnostics.Contracts;

namespace QNALib
{
    public abstract class FlowDistribution
    {
        public abstract Variable<double> Demands { get; }
    }

    public class GaussianFlowDistribution : FlowDistribution
    {
        Variable<double> demands;
        Variable<double> demandVariance;

        Variable<int> numSamples;
        VariableArray<double> demandSamples;

        public GaussianFlowDistribution(double[] observedDemands)
            : base()
        {
            demands = Variable.GaussianFromMeanAndVariance(1, 1);
            demandVariance = Variable.GammaFromMeanAndVariance(50, 1);

            numSamples = Variable.New<int>();

            Range demandRange = new Range(numSamples);
            demandSamples = Variable.Array<double>(demandRange);
            using (Variable.ForEach(demandRange))
            {
                demandSamples[demandRange] = Variable.GaussianFromMeanAndVariance(demands, demandVariance);
            }
            numSamples.ObservedValue = observedDemands.Length;
            demandSamples.ObservedValue = observedDemands;
        }

        public override Variable<double> Demands {  get { return demands;  } }
    }

    public class CategoricalFlowDistributionWithPrior : FlowDistribution
    {
        Variable<int> numCategories;
        Variable<int> numSamples;
        VariableArray<double> categoryValues;
        VariableArray<int> categorySamples;
        Variable<Vector> categoryParam;
        Variable<Dirichlet> categoryParamPrior;
        Variable<int> category;
        Variable<double> demands;
        static int numFD = 0;

        public override Variable<double> Demands { get { return demands; } }

        public CategoricalFlowDistributionWithPrior(double[] observedDemands, int numLevels)
        {
            numFD++;

            numCategories = Variable.New<int>().Named("numCategories" + numFD); // NB added
            numSamples = Variable.New<int>().Named("numSamples" + numFD);    // NB added 
            demands = Variable.New<double>().Named("demands" + numFD);

            Range C = new Range(numCategories);
            Range N = new Range(numSamples);

            categoryParamPrior = Variable.New<Dirichlet>().Named("categoryParamPrior" + numFD);
            categoryParam = Variable<Vector>.Random(categoryParamPrior).Named("categoryParam" + numFD);
            categoryParam.SetValueRange(C);

            categorySamples = Variable.Array<int>(N).Named("categorySamples" + numFD);
            categorySamples.SetValueRange(C);

            using (Variable.ForEach(N))
            {
                categorySamples[N] = Variable.Discrete(categoryParam);
            }

            categoryValues = Variable.Array<double>(C).Named("categoryValues" + numFD);

            double m = observedDemands.Min();
            double M = observedDemands.Max();

            double bucket_size = (M - m) / numLevels;

            int[] observedCategories = new int[observedDemands.Length];

            for (int ii = 0; ii < observedCategories.Length; ii++)
            {
                int bucket = (int)Math.Ceiling((observedDemands[ii] - m) / bucket_size) - 1;

                if (bucket < 0) // corner case: bucket for the least demand would be -1
                    bucket = 0;
                observedCategories[ii] = bucket;
            }

            numCategories.ObservedValue = numLevels;
            categoryParamPrior.ObservedValue = Dirichlet.Symmetric(numLevels, 1); // choosing 1 as the default value of alpha
            // NOTE: we may need to do some symmmtry breaking initialisation of categoryParam before starting inference
            numSamples.ObservedValue = observedCategories.Length;
            categorySamples.ObservedValue = observedCategories;

            double[] categoryValuesConcrete = new double[numLevels];
            // choosing the higher end as the bucket representative value
            // trying to be conservative
            for (int jj = 1; jj <= numLevels; jj++)
            {
                categoryValuesConcrete[jj-1] = m + bucket_size * jj;
            }

            categoryValues.ObservedValue = categoryValuesConcrete;

            category = Variable.Discrete(categoryParam).Named("category" + numFD);
            //category.SetValueRange(C);

            using (Variable.Switch(category))
            {
                this.demands.SetTo(categoryValues[category]);
            }
        }
    }

    public class CategoricalFlowDistribution : FlowDistribution
    {
        Variable<int> numCategories;
        VariableArray<double> categoryValues;
        Variable<int> category;
        Variable<double> demands;

        static int numFD = 0;

        public override Variable<double> Demands { get { return demands; } }

        public CategoricalFlowDistribution(double[] observedDemands, int numLevels)
        {
            numFD++;
            numCategories = Variable.New<int>().Named("numCategories" + numFD); // NB added
            demands = Variable.New<double>().Named("demands" + numFD);

            Range C = new Range(numCategories).Named("C" + numFD);

            categoryValues = Variable.Array<double>(C).Named("categoryValues" + numFD);

            double m = observedDemands.Min();
            double M = observedDemands.Max();

            double bucket_size = (M - m) / numLevels;

            double[] categoryMLE = new double[numLevels];

            for (int ii = 0; ii < observedDemands.Length; ii++)
            {
                int bucket = (int)Math.Ceiling((observedDemands[ii] - m) / bucket_size) - 1;

                if (bucket < 0) // corner case: bucket for the least demand would be -1
                    bucket = 0;
                categoryMLE[bucket]++;
            }

            numCategories.ObservedValue = numLevels;

            double[] categoryValuesConcrete = new double[numLevels];
            // choosing the higher end as the bucket representative value
            // trying to be conservative
            for (int jj = 1; jj <= numLevels; jj++)
            {
                categoryValuesConcrete[jj-1] = m + bucket_size * jj;
            }

            categoryValues.ObservedValue = categoryValuesConcrete;

            //Range C = new Range(numCategories);
            category = Variable.Discrete(categoryMLE).Named("category" + numFD);
            category.SetValueRange(C);
            using (Variable.Switch(category))
            {
                this.demands.SetTo(categoryValues[category]);
            }
        }
    }
#if false
    public class FlowDistribution
    {
        VariableArray<double> Demands;
        Variable<int>         numDemands;
        Variable<Gaussian>    DemandAveragePrior;
        Variable<Gamma>       DemandNoisePrior;
        Variable<double>      DemandAverage;
        Variable<double>      DemandNoise;
 
        public Variable<double> Demand { get { return this.DemandAverage; } }
        public Variable<double> Noise  { get { return this.DemandNoise; } }

        public FlowDistribution(double[] demands)
        {
            DemandAveragePrior = Variable.New<Gaussian>();  
            DemandNoisePrior = Variable.New<Gamma>();
            DemandAverage = Variable.GaussianFromMeanAndVariance(1, 1); //  Variable<double>.Random(DemandAveragePrior);
            DemandNoise = Variable.GammaFromMeanAndVariance(50, 1); //  Variable<double>.Random(DemandNoisePrior);
 
            numDemands = Variable.New<int>();
            Range demandRange = new Range(numDemands);
            Demands = Variable.Array<double>(demandRange);
            using (Variable.ForEach(demandRange)) {
                Demands[demandRange] = Variable.GaussianFromMeanAndPrecision(DemandAverage, DemandNoise);
            }
            numDemands.ObservedValue = demands.Length;
            Demands.ObservedValue = demands;
        }
    }
#endif

    public class FlowPacking
    {
        public SwanNetwork                sn;
        RegionPair[]                      index2flow;
        Dictionary<RegionPair, int>       flow2index;
        Dictionary<RegionPair, FlowDistribution> trafficMatrix;
        Dictionary<SwanPathHop, Variable<double>> bw;

        public FlowPacking(SwanNetwork sn)
        {
            this.sn = sn;
            int numFlows = this.sn.end2endFlows.Count;

            // associate a unique integer with each flow.
            this.index2flow = new RegionPair[numFlows];
            this.flow2index = new Dictionary<RegionPair, int>();
            int index = 0;
            foreach (RegionPair p in sn.end2endFlows.Keys)
            {
                flow2index[p] = index;
                index2flow[index] = p;
                index++;
            }

            this.trafficMatrix = new Dictionary<RegionPair, FlowDistribution>();
            this.bw = null;
        }

        public void AddTraffic(RegionPair p, FlowDistribution h)
        {
            this.trafficMatrix[p] = h;
        }

        //
        // Setup:
        //   Each flow has a probability distribution of loads.
        //   Each flow traverses a set of hops (possibly weighted by redundant routing).
        //   Each hop has a probability of exceeding a capacity threshold.
        //   Compute the probability that some hop has the capacity threshold exceeded.
        //
        // initially, load distribution per Hop is 0.
        // for each Flow f:
        //     for each Path p on f with weight w 
        //         for each Hop h on p:
        //             add distribution for f scaled by w to h.
        // (weight is a percentage between 0 and 100, the weights add up to 100).
        //
        // Observe the propabilities that some hop exceeds a capacity threshold.
        //

        Dictionary<SwanPathHop, Variable<double>> ComputeBandwidths()
        {
            if (bw != null)
            {
                return bw;
            }
            bw = new Dictionary<SwanPathHop, Variable<double>>();
            foreach (var f in sn.end2endFlows.Keys)
            {
                var paths = sn.end2endFlows[f];
                var histogram = trafficMatrix[f];
                double sumOfWeights = paths.Sum(path => path.weight);
                foreach (var path in paths)
                {
                    double w = path.weight / sumOfWeights;
                    foreach (var hop in path.hops)
                    {
                        if (bw.ContainsKey(hop))
                        {
                            bw[hop] += histogram.Demands * w;
                        }
                        else
                        {
                            bw[hop] = histogram.Demands * w;
                        }
                    }
                }
            }
            return bw;
        }

        public void Pack()
        {
            var bw = ComputeBandwidths();
            Variable<double> threshold = (Variable.New<double>()).Named("threshold");
            Variable<bool> below_threshold = true;
            threshold.ObservedValue = 0;
            foreach (var p in bw) {
                below_threshold = below_threshold & (p.Value < threshold * p.Key.capacity);
            }
            var ie = new InferenceEngine();

            // Observe thresholds on linkUtilization.
            // E.g., what is the probability the capacity is reached on some link.
            //       what is the probability that x% of the capacity is reached on some link.
            //          for x = 10, 20, 30, ... 90, 95, 100
            //       what is the probability that x% of capacity is reached on two links...

            for (int i = 0; i < 200; ++i)
            {                            
                Console.WriteLine("{0} = {1}", threshold.ObservedValue, ie.Infer(below_threshold));
                threshold.ObservedValue = threshold.ObservedValue + 0.005;
                Console.ReadKey();
            }	    
        }

        public void NetworkScratchCapacity()
        {
            var bw = ComputeBandwidths();
            Variable<double> result = Variable.New<double>();
            result = 0;
            foreach (var p in bw)
            {
                result = result + p.Key.capacity - p.Value;                
            }
            var ie = new InferenceEngine();
            Console.WriteLine("Scratch Capacity: {0}", ie.Infer(result));
        }

        // ​STDDEV(link_bandwidths)​ 
        public void LinkUtilization()
        {            
            var bw = ComputeBandwidths();           
            Variable<double> avg = Variable.New<double>();
            avg = 0;
            int count = 0;
            foreach(var p in bw)
            {
                ++count;
                avg += p.Value;
            }
            avg /= count;
            Variable<double> std = Variable.New<double>();
            std = 0;
            foreach (var p in bw)
            {
                std += (avg - p.Value) * (avg - p.Value);                 
            }            
            std /= count;            
            // TBD: must be possible to do simpler and more efficient.
            // compute standard deviation of p.Value for p in bw.
            var ie = new InferenceEngine();
            Console.WriteLine("Link Utilization: {0}", Math.Sqrt(ie.Infer<Gamma>(std).GetVariance()));
        }

        public void SaturationPoint()
        {
            var bw = ComputeBandwidths();
            Variable<double> sat_point = Variable.New<double>();
            sat_point = 1;
            foreach (var p in bw)
            {
                sat_point = -Variable.Max(-sat_point, (p.Value - p.Key.capacity) / p.Key.capacity);
            }
            var ie = new InferenceEngine();
            Console.WriteLine("Saturation point {0}", ie.Infer(sat_point));
        }

    }
}

/** 

    Total Loss Ratio 
    Total loss ratio in percentage  ​
    network 
    (total_demand - total_throughput) / total_demand ​ 

    Total k Worst Case Loss Ratio​ 
    Total worst case loss ratio when bringing down K links at the time 
    network​​ 
    MAX(total_loss_ratio) for network with 1 link down
    (total_loss_ratio) for network with 1 link down
    Insights about the resiliency to 1 link loss of the network. 

    ​Flows Weighted Latency 
    Total Flow latency weighted by their bandwidth 
    network 
    weighted_sum = 0
    FOREACH (flows)
    {
        weighted_sum += ​flow_latencies * (flow_bandwidths / total_throughput​)
    }
    weighted_avg = weighted_sum / len(flows)
 ​   With the same loss ratios, lower latencies solvers are preferred.    

 **/
