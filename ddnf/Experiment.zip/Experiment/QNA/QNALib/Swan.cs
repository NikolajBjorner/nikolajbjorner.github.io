﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.Contracts;

namespace QNALib
{

    public class Region
    {
        string region;
        public Region(string r) { region = r; }
        public override bool Equals(object obj)
        {
            return obj != null && obj is Region && this.region == ((Region)obj).region;
        }
        public override string ToString()
        {
            return this.region;
        }
        public override int GetHashCode()
        {
            return this.region.GetHashCode();
        }
    }
    public class Device
    {
        public string name;
        public Region region;
        public Device(string name, string region)
        {
            this.name = name;
            this.region = new Region(region);
        }

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != this.GetType())
            {
                return false;
            }
            Device other = (Device)obj;
            if (other.name != this.name)
            {
                return false;
            }
            return true;
        }

        public override int GetHashCode()
        {
            return name.GetHashCode();
        }

        public override string ToString()
        {
            return name;
        }
    }

    public class DevicePair : Tuple<Device, Device> {
        public DevicePair(Device a, Device b) : base(a,b)
        {            
        }
    }

    public class RegionPair : Tuple<Region, Region>
    {
        public RegionPair(Region a, Region b) : base(a, b) { }
    }
    
    public class SwanPathHop
    {
        public Device startDevice;
        public Device endDevice;
        public string startPort;
        public string endPort;
        public int    capacity;
        public int    latency;

        public SwanPathHop(Device sd, Device ed, string sp, string ep, int capacity = 100000, int latency = 1)
        {
            this.startDevice = sd;
            this.endDevice   = ed;
            this.startPort   = sp;
            this.endPort     = ep;
            this.capacity    = capacity;
            this.latency     = latency;
        }

        public override bool Equals(object obj)
        {
            if (obj == null || obj.GetType() != this.GetType())
            {
                return false;
            }
            SwanPathHop other = (SwanPathHop)obj;
            return
                this.startDevice == other.startDevice &&
                this.endDevice == other.endDevice &&
                this.startPort == other.startPort &&
                this.endPort == other.endPort;
            // capacity, latency is not part of equality
        }

        public override int GetHashCode()
        {
            return Tuple.Create(startDevice, startPort, endDevice, endPort).GetHashCode();
        }

        public override string ToString()
        {
            return "'" + startDevice + ":" + startPort + " " + endDevice + ":" + endPort + "'";
        }
    }

    public class SwanPath
    {
        public Region            source;
        public Region            destination;
        public List<SwanPathHop> hops;
        public int               weight;
        public int               latency;

        public SwanPath()
        {
            this.hops = new List<SwanPathHop>();
            this.latency = 0;
            this.weight = 1;
        }

        public SwanPath(SwanPathHop[] hops, int weight)
        {
            this.source = hops[0].startDevice.region;
            this.destination = hops[hops.Length - 1].endDevice.region;
            this.weight = weight;
            this.latency = hops.Sum(hop => hop.latency);
            this.hops = new List<SwanPathHop>(hops);
            for (int i = 0; i < hops.Length-1; ++i)
            {
                Contract.Assert(hops[i].endDevice == hops[i + 1].startDevice);
                Contract.Assert(hops[i].endPort == hops[i + 1].startPort);                
            }                       
        }

        public RegionPair EndPoints {  get { return new RegionPair(source, destination); } }

        public void SetSource(Device s)
        {
            this.source = s.region;
        }

        public void SetDestination(Device d)
        {
            this.destination = d.region;
        }

        public void SetWeight(int wt)
        {
            this.weight = wt;
        }

        public void AddHopLast(SwanPathHop sph) {
            hops.Add(sph);
            this.latency += sph.latency;
        }
    }

    public class SwanNetwork
    {
        public Dictionary<Device, Device> devices;
        public Dictionary<SwanPathHop, SwanPathHop> hops;
        public Dictionary<RegionPair, List<SwanPath>> end2endFlows;

        public SwanNetwork()
        {
            devices = new Dictionary<Device, Device>();
            hops = new Dictionary<SwanPathHop, SwanPathHop>();
            end2endFlows = new Dictionary<RegionPair, List<SwanPath>>();
        }

        public void AddDevice(string name, string region) {
            Device newdvc = new Device(name, region);
            if (!devices.ContainsKey(newdvc))
            {
                devices[newdvc] = newdvc;
            }
        }

        public Device GetDevice(string name)
        {
            return devices[new Device(name, "region")];
        }


        public SwanPathHop AddHop(string sd, string ed, string sp, string ep, int capacity, int latency)
        {
            Device s = this.GetDevice(sd);
            Device e = this.GetDevice(ed);
            SwanPathHop newsph = new SwanPathHop(s, e, sp, ep, capacity, latency);
            if (!hops.ContainsKey(newsph))
            {
                hops[newsph] = newsph;
            }
            return newsph;
        }

        public SwanPathHop GetHop(string sd, string ed, string sp, string ep)
        {
            Device s = this.GetDevice(sd);
            Device e = this.GetDevice(ed);
            SwanPathHop newsph = new SwanPathHop(s, e, sp, ep);
            if (!hops.ContainsKey(newsph))
            {
                hops[newsph] = newsph;
            }
            return hops[newsph];
        }

        public void AddSwanPath(SwanPath path)
        {
            RegionPair pair = new RegionPair(path.source, path.destination);
            if (!end2endFlows.ContainsKey(pair))
            {
                end2endFlows[pair] = new List<SwanPath>();
            }
            end2endFlows[pair].Add(path);
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach(var f in end2endFlows)
            {
                sb.AppendFormat("{0}\n", f.Key);
                foreach (var p in f.Value)
                {
                    sb.Append("  ");
                    foreach (var e in p.hops)
                    {
                        sb.AppendFormat("{0} ", e);
                    }
                    sb.Append(";\n");
                }                
            }
            return sb.ToString();
        }
    }
}
