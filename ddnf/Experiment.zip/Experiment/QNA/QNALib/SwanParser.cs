﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace QNALib
{
    public class SwanParser
    {

        public SwanParser()
        {
        }

        public Dictionary<RegionPair, List<double>> ParseDemands(string baseDirectory)
        {
            var demands = new Dictionary<RegionPair, List<double>>();
            var dirs = System.IO.Directory.EnumerateDirectories(baseDirectory);
            foreach (var dir in dirs)
            {
                string file = String.Format("{0}\\SwanDemands.xml", dir);
                ParseDemandFile(file, demands);
            }
            foreach(var kv in demands)
            {
                Console.WriteLine("{0} num demands: {1}", kv.Key, kv.Value.Count);
            }
            return demands;
        }

        /**
        <SwanDemandList xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <Network>SwanPilot</Network>
          <StartTime>2015-02-07T19:20:55.4722083Z</StartTime>
          <DurationSecs>900</DurationSecs>
          <SwanDemand SourceRegion="CO" DestinationRegion="CH" Application="Default" TrafficClass="BestEffort" Mbps="6878" />
          ...
        </SwanDemandList>
        **/


        void ParseDemandFile(string filePath, Dictionary<RegionPair, List<double>> demands)
        {
            using (XmlReader reader = XmlReader.Create(filePath))
            {
                while(reader.ReadToFollowing("SwanDemand"))
                {
                    string src = reader["SourceRegion"];
                    string dst = reader["DestinationRegion"];
                    double bw = Convert.ToDouble(reader["Mbps"]);
                    RegionPair p = new RegionPair(new Region(src), new Region(dst));                    
                    InsertDemand(demands, p, bw);
                }
            }
        }

        void InsertDemand(Dictionary<RegionPair, List<double>> demands, RegionPair p, double bw)
        {
            if (!demands.ContainsKey(p))
            {
                demands[p] = new List<double>();
            }
            //Console.WriteLine("Adding demand {0} to {1}", bw, p);
            demands[p].Add(bw);
        }


        public void ParsePaths(SwanNetwork sn, string pathsXmlFilename)
        {
            using (XmlReader reader = XmlReader.Create(pathsXmlFilename))
            {
                while (reader.ReadToFollowing("SwanPath"))
                {
                    XmlReader inner = reader.ReadSubtree();
                    SwanPath sp = new SwanPath();
                    while (inner.Read())
                    {
                        if (inner.IsStartElement())
                        {
                            switch (inner.Name.ToString())
                            {
                                case "Source":
                                    sp.SetSource(sn.GetDevice(inner.ReadElementContentAsString()));
                                    break;
                                case "Destination":
                                    sp.SetDestination(sn.GetDevice(inner.ReadElementContentAsString()));
                                    break;
                                case "ComputedWeight":
                                    sp.SetWeight(inner.ReadElementContentAsInt());
                                    break;
                                case "Hops":
                                    XmlReader hoplist = inner.ReadSubtree();
                                    while (hoplist.Read())
                                    {
                                        if (hoplist.IsStartElement())
                                        {
                                            switch (hoplist.Name.ToString())
                                            {
                                                case "SwanPathHop":
                                                    SwanPathHop sph = sn.GetHop(
                                                        hoplist["StartDevice"],
                                                        hoplist["EndDevice"],
                                                        hoplist["StartPort"],
                                                        hoplist["EndPort"]);
                                                    sp.AddHopLast(sph);
                                                    break;
                                                default:
                                                    break;
                                            }
                                        }
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    sn.AddSwanPath(sp);
                }
            }
        }

        public void ParseTopology(SwanNetwork sn, string topologyXmlFilename)
        {
            using (XmlReader reader = XmlReader.Create(topologyXmlFilename))
            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        //return only when you have START tag
                        switch (reader.Name.ToString())
                        {
                            case "Device":
                                sn.AddDevice(reader["Name"], reader["Region"]);
                                break;

                            case "Link": {
                                int latency = 1;

                                var sd = reader["StartDevice"];
                                var ed = reader["EndDevice"];
                                var sp = reader["StartPort"];
                                var ep = reader["EndPort"];
                                var bw = Convert.ToInt32(reader["Bandwidth"]);

                                // retrieve latency from <PhyAttributes> sub-tag.
                                XmlReader inner = reader.ReadSubtree();
                                if (inner.ReadToFollowing("PhyAttributes")) {
                                    latency = Convert.ToInt32(inner["LatencyMs"]);
                                }
                                sn.AddHop(sd, ed, sp, ep, bw, latency);
                                break;
                            }
                        }
                    }
                }
            }
        }

        public SwanNetwork ParseNetwork(string topologyXmlFilename, string pathsXmlFilename)
        {
            SwanNetwork sn = new SwanNetwork();
            ParseTopology(sn, topologyXmlFilename);
            ParsePaths(sn, pathsXmlFilename);
            return sn;
        }
    }
}
