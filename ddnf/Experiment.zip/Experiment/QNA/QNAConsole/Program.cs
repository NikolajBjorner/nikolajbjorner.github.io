﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using QNALib;

namespace TEUU
{
    class Program
    {

        static void ParseArguments(string[] args)
        {
            if (args.Length < 1)
            {
                return;
            }
            /*
            if (args[0] == "-engine")
            {
                if (args.Length < 2)
                {
                    return;
                }
                if (args[1] == "he" || args[1] == "HE")
                {
                    engine = Engine.HE;
                }
                
                ParseArguments(args.Skip(2).ToArray());
            }
            else if (args[0] == "-directory")
            {
                if (args.Length < 2)
                {
                    return;
                }
                directory = args[1];
                ParseArguments(args.Skip(2).ToArray());
            }*/
            else
            {
                return;
            }
        }

        static void Main(string[] args)
        {
            Main2(args);
        }

        static void Main0(string[] args)
        {
            string topologyXmlFilename = @"..\..\..\..\SWAN\Idfx_Demands\SwanTopology.xml";
            string pathsXmlFilename = @"..\..\..\..\SWAN\Idfx_Demands\SwanNetworkPaths.xml";

            SwanParser sParser = new SwanParser();
            SwanNetwork sn = sParser.ParseNetwork(topologyXmlFilename, pathsXmlFilename);
        }

        static void Main1(string[] args)
        {
            SwanParser sp = new SwanParser();
            string top = @"D:\\\\QnA\\NetworkSimulationData\\SampleTopology.xml";
            string paths = @"D:\\\\QnA\\NetworkSimulationData\\SamplePaths.xml";
            var demands = sp.ParseDemands("D:\\\\QnA\\NetworkSimulationData\\reports");
            SwanNetwork sn = sp.ParseNetwork(top, paths);
            Console.WriteLine("{0}", sn);
            Console.ReadKey();
            FlowPacking fp = new FlowPacking(sn);
            foreach(var d in demands)
            {
                fp.AddTraffic(d.Key, new GaussianFlowDistribution(d.Value.ToArray()));
            }
            fp.Pack();
            return;
        }

        /// <summary>
        ///  D1 -> D2 -> D3
        ///     \   |
        ///        D4 -> D5
        /// </summary>
        /// <param name="args"></param>
        static void Main2(string[] args)
        {

            SwanNetwork sn = new SwanNetwork();
            sn.AddDevice("D1","D1");
            sn.AddDevice("D2","D2");
            sn.AddDevice("D3","D3");
            sn.AddDevice("D4","D4");
            sn.AddDevice("D5","D5");
            sn.AddDevice("D6","D6");
            var D1D2 = sn.AddHop("D1", "D2", "p", "p", 100, 1);
            var D1D3 = sn.AddHop("D1", "D3", "p", "p", 100, 1);
            var D2D3 = sn.AddHop("D2", "D3", "p", "p", 100, 2);
            var D3D2 = sn.AddHop("D3", "D2", "p", "p", 100, 3);
            var D3D4 = sn.AddHop("D3", "D4", "p", "p", 100, 4);
            var D2D4 = sn.AddHop("D2", "D4", "p", "p", 10, 1);
            var D2D5 = sn.AddHop("D2", "D5", "p", "p", 20, 2);
            var D3D5 = sn.AddHop("D3", "D5", "p", "p", 100, 2);
            var D4D6 = sn.AddHop("D4", "D6", "p", "p", 100, 2);
            var D5D6 = sn.AddHop("D5", "D6", "p", "p", 100, 2);
            // three alternative paths from D1 to D6
            var sp1 = new SwanPath(new SwanPathHop[] { D1D2, D2D3, D3D4, D4D6 }, 20);
            var sp2 = new SwanPath(new SwanPathHop[] { D1D3, D3D4, D4D6 }, 60);
            var sp3 = new SwanPath(new SwanPathHop[] { D1D2, D2D4, D4D6 }, 10);
            var sp4 = new SwanPath(new SwanPathHop[] { D1D3, D3D2, D2D5, D5D6 }, 10);
            sn.AddSwanPath(sp1);
            sn.AddSwanPath(sp2);
            sn.AddSwanPath(sp3);
            sn.AddSwanPath(sp4);
            // one path from D2 to D5
            var sp5 = new SwanPath(new SwanPathHop[] { D2D3, D3D5 }, 100);
            sn.AddSwanPath(sp5);
            QNALib.FlowPacking fp = new QNALib.FlowPacking(sn);
            fp.AddTraffic(sp1.EndPoints, new CategoricalFlowDistributionWithPrior(new double[] { 10, 20, 30, 404, 35, 60, 110, 80, 10, 23 }, 4));
            fp.AddTraffic(sp5.EndPoints, new CategoricalFlowDistributionWithPrior(new double[] { 11, 1, 11, 17, 99, 11, 11, 12, 24, 11 }, 4));
            fp.Pack();
            Console.ReadKey();
        }

    }
}
