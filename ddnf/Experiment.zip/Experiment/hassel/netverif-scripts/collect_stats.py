#!/usr/bin/env python

'''
Copyright (c) 2013, Nuno Lopes
All rights reserved.
'''

from __future__ import division

import sys
sys.path.append('hassel')

import os, time, argparse, math
from headerspace.tf import TF
from headerspace.hs import byte_array_wildcard_to_mask_match_strings, byte_array_to_hs_string


# number of bytes per header field
header_fields = {
                 'vlan':     2,
                 'ip_src':   4,
                 'ip_dst':   4,
                 'ip_proto': 1,
                 'tcp_src':  2,
                 'tcp_dst':  2,
                 'tcp_ctrl': 1
                 }

# src port -> rule*
rules = {}

def import_rules(rtr_name, input_path):
    global rules
    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)

    for rule in tf.rules:
        for src in rule["in_ports"]:
            if not rules.has_key(src):
                rules[src] = []
            rules[src].append(rule)

def is_router(id):
    return (id % 100000) == 0

def get_router(id):
    return id // 100000

def is_in_port(id):
    id = id % 100000
    return id != 0 and (id // 10000) == 0

def is_acl_port(id):
    id = id % 100000
    return (id // 10000) == 1

def is_out_port(id):
    id = id % 100000
    return (id // 10000) == 2

def to_binary(n, bits):
    for i in range(bits-1, -1, -1):
        sys.stdout.write(str(int(bool(n & (1 << i)))))
    print

def is_match_nop(rule_mask, bytes):
    mask = ((1 << (8*bytes)) - 1)
    return (rule_mask & mask) == mask

def extract_match_field(mask, match, offset, size):
    mask = ~int(mask[offset*8:(offset+size)*8], 2)
    match = int(match[offset*8:(offset+size)*8], 2)
    return mask, match

def gen_match_stats(r):
    global header_fields
    data = {}
    offset = 0

    if r["match"] == None:
        return {}

    [mask, match] = byte_array_wildcard_to_mask_match_strings(r["match"])

    for field, size in header_fields.iteritems():
        f_mask, f_match = extract_match_field(mask, match, offset, size)
        offset += size
        data[field] = not is_match_nop(f_mask, size)
    return data

def extract_rewrite_field(mask, match, offset, size):
    mask = int(mask[offset*8:(offset+size)*8], 2)
    match = int(match[offset*8:(offset+size)*8], 2)
    return mask, match

def is_rewrite_nop(rule_mask, rule_match, bytes):
    mask = ((1 << (8*bytes)) - 1)
    return rule_match == 0 and (rule_mask & mask) == mask

def gen_rewrite_stats(r):
    global header_fields
    data = {}
    offset = 0

    if r["action"] != "rw":
        return {}

    match = byte_array_to_hs_string(r["rewrite"])
    mask = byte_array_to_hs_string(r["mask"])

    for field, size in header_fields.iteritems():
        f_mask, f_match = extract_rewrite_field(mask, match, offset, size)
        offset += size
        data[field] = not is_rewrite_nop(f_mask, f_match, size)
        '''
        if not is_rewrite_nop(f_mask, f_match, size):
            print
            to_binary(f_match, 32)
            to_binary(f_mask, 32)
            '''
    return data

def sum_match_stats(map, new):
    for k,v in new.iteritems():
        if not map.has_key(k):
            map[k] = v
        else:
            map[k] += v


num_rules = 0
num_rewrite_rules = 0
num_rules_type = {'acl': 0, 'in': 0, 'out': 0, 'router': 0}
num_rewrite_rules_type = {'acl': 0, 'in': 0, 'out': 0, 'router': 0}

num_rules_deps = 0
min_dependencies = 10000000000
max_dependencies = 0
total_dependencies = 0
deps_per_port_type = {'acl': 0, 'in': 0, 'out': 0, 'router': 0}

in_per_router = {}
out_per_router = {}

num_dsts = {}
seen_routers = set()

match_stats = {}
match_stats_per_type = {'acl': {}, 'in': {}, 'out': {}, 'router': {}}

rewrite_stats = {}
rewrite_stats_per_type = {'acl': {}, 'in': {}, 'out': {}, 'router': {}}


def extract_stats(r, in_port):
    global num_rules, num_rewrite_rules, num_rules_type, num_rewrite_rules_type, num_rules_deps
    global min_dependencies, max_dependencies, total_dependencies, deps_per_port_type
    global in_per_router, out_per_router, seen_routers, num_dsts
    global match_stats, match_stats_per_type, rewrite_stats, rewrite_stats_per_type

    num_rules += 1
    num_rewrite_rules += (r["action"] == "rw")

    router = get_router(in_port)
    seen_routers.add(router)

    deps = len(r["affected_by"])
    min_dependencies = min(min_dependencies, deps)
    max_dependencies = max(max_dependencies, deps)
    total_dependencies += deps
    num_rules_deps += (deps > 0)

    dsts = len(r["out_ports"])

    ## flow: in_port -> router -> ACL -> out_port
    if is_acl_port(in_port):
        assert(dsts <= 1)
        type = 'acl'

        if not out_per_router.has_key(router):
            out_per_router[router] = set()
        out_per_router[router].add(in_port)

    elif is_in_port(in_port):
        assert(dsts <= 1)
        type = 'in'

        if not in_per_router.has_key(router):
            in_per_router[router] = set()
        in_per_router[router].add(in_port)

    elif is_out_port(in_port):
        assert(dsts == 1)
        type = 'out'

    else:
        assert(is_router(in_port))
        type = 'router'

    num_rules_type[type] += 1
    num_rewrite_rules_type[type] += (r["action"] == "rw")
    deps_per_port_type[type] += (deps > 0)

    if num_dsts.has_key(dsts):
        num_dsts[dsts] += 1
    else:
        num_dsts[dsts] = 1

    sum_match_stats(match_stats, gen_match_stats(r))
    sum_match_stats(match_stats_per_type[type], gen_match_stats(r))

    sum_match_stats(rewrite_stats, gen_rewrite_stats(r))
    sum_match_stats(rewrite_stats_per_type[type], gen_rewrite_stats(r))


def main():
    rtr_names = [
                 "bbra_rtr",
                 "bbrb_rtr",
                 "boza_rtr",
                 "bozb_rtr",
                 "coza_rtr",
                 "cozb_rtr",
                 "goza_rtr",
                 "gozb_rtr",
                 "poza_rtr",
                 "pozb_rtr",
                 "roza_rtr",
                 "rozb_rtr",
                 "soza_rtr",
                 "sozb_rtr",
                 "yoza_rtr",
                 "yozb_rtr",
                 "backbone_topology"
                 ]
  
    parser = argparse.ArgumentParser(description='Collect statistics of network routing')
    parser.add_argument('--input_path', dest='input_path', required=True)
    args = parser.parse_args()
    
    input_path = args.input_path

    for rtr_name in rtr_names:
        import_rules(rtr_name, input_path)

    global rules
    for in_port, rs in rules.iteritems():
        for r in rs:
            extract_stats(r, in_port)

    global num_rules, num_rewrite_rules, num_rules_type, num_rewrite_rules_type, num_rules_deps
    global min_dependencies, max_dependencies, total_dependencies, deps_per_port_type
    global in_per_router, out_per_router, seen_routers, num_dsts
    global match_stats, match_stats_per_type

    print
    print "Num routers: %d" % len(seen_routers)
    print "Num rules: %d" % num_rules
    print "Num rewrite rules: %d" % num_rewrite_rules
    print

    for type, num in num_rules_type.iteritems():
        print "Num %s rules: %d" % (type, num)

    print
    print "Min dependencies: %d" % min_dependencies
    print "Max dependencies: %d" % max_dependencies
    print "Num rules w/ dependencies: %d (%.2f%%)" % (num_rules_deps, num_rules_deps/num_rules*100)
    print "Avg dependencies: %.2f" % (total_dependencies/num_rules)
    print "Avg dependencies of rules w/ deps: %.2f" % (total_dependencies/num_rules_deps)

    print
    for type, num in deps_per_port_type.iteritems():
        print "%s rules that have deps: %d (%.2f%%)" % (type, num, num/num_rules_type[type]*100)

    print
    for dsts, count in num_dsts.iteritems():
        print "%d rules have %d destinations (%.2f%%)" % (count, dsts, count/num_rules*100)

    print
    for router, ports in in_per_router.iteritems():
        numin = len(ports)
        numout = len(out_per_router[router])
        if numin == numout:
            print "Router %d has %d I/O ports" % (router, numin)
        else:
            print "Router %d has %d in ports and %d out ports" % (router, numin, numout)

    print '\n----------------------------------------------'
    for k,v in match_stats.iteritems():
        print "Field %s is matched %d times (%.2f%%)" % (k, v, v/num_rules*100)

    for type, map in match_stats_per_type.iteritems():
        if map == {}:
            continue
        print "\nRule type %s" % type
        for k,v in map.iteritems():
            print "Field %s is matched %d times (%.2f%%)" % (k, v, v/num_rules_type[type]*100)

    print '\n----------------------------------------------'
    for k,v in rewrite_stats.iteritems():
        print "Field %s is rewritten %d times (%.2f%%)" % (k, v, v/num_rewrite_rules*100)

    for type, map in rewrite_stats_per_type.iteritems():
        if num_rewrite_rules_type[type] == 0:
            continue
        print "\nRule type %s" % type
        for k,v in map.iteritems():
            print "Field %s is rewritten %d times (%.2f%%)" % (k, v, v/num_rewrite_rules_type[type]*100)


if __name__ == "__main__":
    main()
