#!/usr/bin/env python

'''
Copyright (c) 2013, Nuno Lopes
All rights reserved.
'''

from __future__ import division

import sys
sys.path.append('hassel')

import os, time, argparse, math, random
from headerspace.tf import TF
from headerspace.hs import *
from config_parser.helper import *

NUM_BITS = 128


def is_power_two(n):
    return n != 0 and (n & (n - 1)) == 0

NTF = TF(2 * (NUM_BITS / 8))
ports = {}

def datacenter_port(id):
    return 1000000 + id * 100000

def mk_port(datacenter):
    global ports
    if ports.has_key(datacenter):
        ports[datacenter] = p = ports[datacenter] + 1
    else:
        ports[datacenter] = p = 1
    return datacenter_port(datacenter) + p

def match_ips(ip, ip2, bits):
    mask = (0xFFFFFFFF >> bits) << bits
    return ip & mask == ip2 & mask

# match ip/32-bits,  e.g. 10.0.0.0/8  (w/ n = 24)
def match_ip(ip, bits, offset):
    assert bits >= 0
    assert bits <= 32

    str = ''
    for i in range(0, 8*offset):
        str += 'x'

    # ip is big endian (most significant bit first)
    for i in range(31, bits - 1, -1):
        if ip & (1 << i):
            str += '1'
        else:
            str += '0'

    for i in range(8*offset + 32 - bits, NUM_BITS):
        str += 'x'

    assert len(str) == NUM_BITS
    return str

def match_src_ip(ip, bits):
    return match_ip(ip, bits, 2)

def match_dst_ip(ip, bits):
    return match_ip(ip, bits, 6)

def match_src_ip2(m, ip, bits):
    m = list(m)
    offset = 8 * 2
    for i in range(bits, 32):
        idx = offset + 32 - i - 1
        if ip & (1 << i):
            m[idx] = '1'
        else:
            m[idx] = '0'

    return "".join(m)

def match_port(m, port, offset):
    # TCP port (16 bits) is big endian (most significant bit first)
    m = list(m)
    for i in range(0, 16):
        idx = offset * 8 + 16 - i - 1
        if port & (1 << i):
            m[idx] = '1'
        else:
            m[idx] = '0'
    
    # force TCP protocol
    tcp = 6
    for i in range(0, 8):
        idx = 11 * 8 - i - 1
        if tcp & (1 << i):
            m[idx] = '1'
        else:
            m[idx] = '0'

    return "".join(m)

def match_src_port(m, port):
    return match_port(m, port, 11)

def match_dst_port(m, port):
    return match_port(m, port, 13)

def match_all():
    str = ''
    for i in range(0, NUM_BITS):
        str += 'x'
    return str

def rewrite_mask(offset, bits):
    str = ''

    for i in range(0, 8*offset):
        str += '1'

    for i in range(8*offset, 8*(offset+bits)):
        str += '0'

    for i in range(8*(offset+bits), NUM_BITS):
        str += '1'

    assert len(str) == NUM_BITS
    return str

def rewrite_src_ip_mask():
    return rewrite_mask(2, 4)

def rewrite_dst_ip_mask():
    return rewrite_mask(6, 4)

def rewrite_ip(ip, bits, offset):
    str = ''

    for i in range(0, 8*offset):
        str += '0'

    for i in range(31, bits - 1, -1):
        if ip & (1 << i):
            str += '1'
        else:
            str += '0'

    for i in range(8*offset + 32 - bits, 8*offset + 32):
        str += 'x'

    for i in range(8*offset + 32, NUM_BITS):
        str += '0'

    assert len(str) == NUM_BITS
    return str

def rewrite_src_ip(ip, bits):
    return rewrite_ip(ip, bits, 2)

def rewrite_dst_ip(ip, bits):
    return rewrite_ip(ip, bits, 6)

def get_host_services(ips, services, host):
    srvs = set()
    for s in services:
        for ip, bits in ips[s]:
            if match_ips(ip, host, bits):
                srvs.add(s)
    return srvs


g_bits_leaf_ips = 0
g_router_branching = 0
g_router_replication = 0
g_num_datacenters = 0
g_num_hosts_per_router = 0
g_num_ips_per_host = 0
g_num_leaf_routers = 0
g_num_services = 0
g_services_datacenter = []
g_acl_services = {}
g_services_ips = {}
g_public_port = 0
g_public_ip = 0
g_private_ip = 0
g_bits_datacenter = 0


def gen_datacenter(datacenter, ip, bits, height, ports):
    global NTF
    global g_bits_leaf_ips, g_router_branching, g_router_replication, g_num_datacenters
    global g_num_hosts_per_router, g_num_ips_per_host, g_num_leaf_routers, g_num_services
    global g_services_datacenter, g_acl_services, g_services_ips, g_public_port, g_public_ip
    global g_private_ip, g_bits_datacenter

    if height == 0:
        assert bits == g_bits_leaf_ips
        assert len(ports) == 1

        # router -> ACL port.
        # FIXME: we assume all hosts in this router have the same ACLs, which may not be true (and then we need multiple ACL ports)
        acl_port = mk_port(datacenter)
        router_srvs = get_host_services(g_services_ips, g_services_datacenter[datacenter], ip)

        print "Services of router %d (%s/%d): %s" % (ports[0], int_to_dotted_ip(ip), 32-g_bits_leaf_ips, router_srvs)
        assert router_srvs != set()

        for s in router_srvs:
            tcp_port = g_public_port + s
            # if accessible from Internet, then it's accessible by everyone
            if g_acl_services[g_num_services][s]:
                rule = NTF.create_standard_rule(ports,
                                                match_dst_port(match_dst_ip(ip, g_bits_leaf_ips), tcp_port),
                                                [acl_port],
                                                None, None, None, [])
                NTF.add_fwd_rule_no_influence(rule)
            else:
                # add ACLs to limit service to allowed services
                for user in range(0, g_num_services):
                    if not g_acl_services[user][s]:
                        continue

                    user_port = g_public_port + user
                    for user_ip, user_bits in g_services_ips[user]:
                        match = match_dst_port(match_dst_ip(ip, g_bits_leaf_ips), tcp_port)
                        match = match_src_port(match_src_ip2(match, user_ip, user_bits), user_port)
                        rule = NTF.create_standard_rule(ports,
                                                        match,
                                                        [acl_port],
                                                        None, None, None, [])
                        NTF.add_fwd_rule_no_influence(rule)

        new_bits = int(math.log(g_num_ips_per_host, 2))
        ip_start = ip
        ip_inc = 1 << new_bits

        # each host gets 2 ports: one I, and one O, to avoid loops
        for i in range(0, g_num_hosts_per_router):
            # link router -> host
            rule = NTF.create_standard_rule([acl_port], match_dst_ip(ip, new_bits), [mk_port(datacenter)], None, None, None, [])
            NTF.add_fwd_rule_no_influence(rule)

            srvs = get_host_services(g_services_ips, g_services_datacenter[datacenter], ip)
            assert srvs == router_srvs

            # link host -> router
            # TODO: add ACLs here as well?
            rule = NTF.create_standard_rule([mk_port(datacenter)], match_src_ip(ip, new_bits), ports, None, None, None, [])
            NTF.add_fwd_rule_no_influence(rule)
            ip += ip_inc

        # drop packets from this router to non-existent hosts and services
        rule = NTF.create_standard_rule(ports, match_dst_ip(ip_start, g_bits_leaf_ips), [], None, None, None, [])
        NTF.add_fwd_rule(rule)
        return

    # height > 0: add intermediate routers to fat routing tree
    new_bits = bits - int(math.log(g_router_branching, 2))
    ip_inc = 1 << new_bits

    # no replication on leaf routers
    if height == 1:
        router_replication = 1
    else:
        router_replication = g_router_replication

    for i in range(0, g_router_branching):
        new_routers = []
        for j in range(0, router_replication):
           new_routers.append(mk_port(datacenter))

        # recurse first, so that rules are ordered properly
        gen_datacenter(datacenter, ip, new_bits, height-1, new_routers)

        # link ports -> newrouters
        rule = NTF.create_standard_rule(ports, match_dst_ip(ip, new_bits), new_routers, None, None, None, [])
        NTF.add_fwd_rule_no_influence(rule)

        # link newrouters -> ports
        rule = NTF.create_standard_rule(new_routers, match_all(), ports, None, None, None, [])
        NTF.add_fwd_rule(rule)
        ip += ip_inc


def get_internal_ip(services_ips, ip_datacenter):
    global g_bits_datacenter
    my_ips = []
    for ip, bits in services_ips:
        if match_ips(ip, ip_datacenter, g_bits_datacenter):
            my_ips.append((ip,bits))

    assert len(my_ips) == 1
    return my_ips[0][0], my_ips[0][1]


def gen_backbone_topology():
    global NTF
    global g_bits_leaf_ips, g_router_branching, g_router_replication, g_num_datacenters
    global g_num_hosts_per_router, g_num_ips_per_host, g_num_leaf_routers, g_num_services
    global g_services_datacenter, g_acl_services, g_services_ips, g_public_port, g_public_ip
    global g_private_ip, g_bits_datacenter

    internet_in = datacenter_port(g_num_datacenters)
    internet_out = mk_port(g_num_datacenters)
    internet_in_filtered = mk_port(g_num_datacenters)

    print "Internet port: %d" % internet_in

    # all-to-all 1 hop topology
    for i in range(0, g_num_datacenters):
        for j in range(0, g_num_datacenters):
            if i == j:
                continue

            ip_dst = g_private_ip + j * (1 << g_bits_datacenter)
            rule = NTF.create_standard_rule([datacenter_port(i)],
                                            match_dst_ip(ip_dst, g_bits_datacenter),
                                            [datacenter_port(j)],
                                            None, None, None, [])
            NTF.add_fwd_rule_no_influence(rule)

    # block traffic from Internet with datacenter public IPs and from local IP addresses
    bits_services = int(math.ceil(math.log(g_num_services, 2)))
    block_ips = [(g_public_ip, bits_services),
                 (dotted_ip_to_int('127.0.0.0'), 32-8),
                 (dotted_ip_to_int('10.0.0.0'), 32-8),
                 (dotted_ip_to_int('172.16.0.0'), 32-12),
                 (dotted_ip_to_int('192.168.0.0'), 32-16)]
    
    for ip, bits in block_ips:
        rule = NTF.create_standard_rule([internet_in],
                                        match_src_ip(ip, bits),
                                        [], None, None, None, [])
        NTF.add_fwd_rule_no_influence(rule)

    # create a link from the internet to a filtered port
    rule = NTF.create_standard_rule([internet_in], match_all(),
                                    [internet_in_filtered], None, None, None, [])
    NTF.add_fwd_rule(rule)

    # internet <-> datacenter
    for i in range(0, g_num_datacenters):
        priv_ip_datacenter = g_private_ip + i * (1 << g_bits_datacenter)

        for s in g_services_datacenter[i]:
            if not g_acl_services[g_num_services][s]:
                continue

            ip = g_public_ip + s
            tcp_port = g_public_port + s
            internal_ip, internal_bits = get_internal_ip(g_services_ips[s], priv_ip_datacenter)

            # internet -> datacenter
            # rewrite dst IP to internal service IP
            rule = NTF.create_standard_rule([internet_in_filtered],
                                            match_dst_port(match_dst_ip(ip, 0), tcp_port),
                                            [datacenter_port(i)],
                                            rewrite_dst_ip_mask(),
                                            rewrite_dst_ip(internal_ip, internal_bits),
                                            None, [])
            NTF.add_rewrite_rule_no_influence(rule)

            # datacenter -> internet
            # rewrite origin internal IP to public IP
            rule = NTF.create_standard_rule([datacenter_port(i)],
                                            match_src_port(match_src_ip(internal_ip, internal_bits), tcp_port),
                                            [internet_out],
                                            rewrite_src_ip_mask(),
                                            rewrite_src_ip(ip, 0),
                                            None, [])
            NTF.add_rewrite_rule(rule)


def main():
    parser = argparse.ArgumentParser(description='Generate cloud-like network topology')
    parser.add_argument('--datacenters', dest='datacenters', required=False, type=int, default=5)
    parser.add_argument('--nodes-per-datacenter', dest='nodes_per_datacenter', required=False, type=int, default=100000)
    parser.add_argument('--num-ips-per-host', dest='num_ips_per_host', required=False, type=int, default=4)
    parser.add_argument('--ports-per-router', dest='ports_per_router', required=False, type=int, default=64)
    parser.add_argument('--ports-per-leaf-router', dest='ports_per_leaf_router', required=False, type=int, default=64)
    parser.add_argument('--router-replication', dest='router_replication', required=False, type=int, default=4)
    parser.add_argument('--num-services', dest='num_services', required=False, type=int, default=25)
    parser.add_argument('--services-per-datacenter', dest='services_per_datacenter', required=False, type=int, default=10)
    parser.add_argument('--services-per-host', dest='services_per_host', required=False, type=int, default=4)
    parser.add_argument('--random-seed', dest='random_seed', required=False, type=int)

    args = parser.parse_args()

    global g_bits_leaf_ips, g_router_branching, g_router_replication, g_num_datacenters
    global g_num_hosts_per_router, g_num_ips_per_host, g_num_leaf_routers, g_num_services
    global g_services_datacenter, g_acl_services, g_services_ips, g_public_port, g_public_ip
    global g_private_ip, g_bits_datacenter

    g_num_datacenters = args.datacenters
    nodes_per_datacenter = args.nodes_per_datacenter
    g_num_ips_per_host = args.num_ips_per_host
    ports_per_router = args.ports_per_router
    ports_per_leaf_router = args.ports_per_leaf_router
    g_router_replication = args.router_replication
    g_num_services = args.num_services
    services_per_datacenter = args.services_per_datacenter
    services_per_host = args.services_per_host

    if args.random_seed != None:
        random.seed(args.random_seed)

    global NTF

    # assign services to datacenters
    unused_services = set(range(0, g_num_services))

    bits_services = int(math.floor(math.log(services_per_datacenter, 2)))
    for i in range(0, g_num_datacenters):
        num_dc_services = 1 << random.randint(0, bits_services)
        s = set()
        if i == (g_num_datacenters-1):
            s = unused_services

        while len(s) < num_dc_services or not is_power_two(len(s)):
            if len(s) == g_num_services:
                print "No luck in picking services at random. Please try again."
                exit()
            s.add(random.randint(0, g_num_services-1))

        g_services_datacenter.append(s)
        unused_services = unused_services.difference(s)

    # compute ACL matrix (acl[i][j] is true iff service i can talk to service j)
    # acl[n_services] is the internet
    for i in range(0, g_num_services+1):
        g_acl_services[i] = {}
        for j in range(0, g_num_services+1):
            if i == j:
                g_acl_services[i][j] = False
            elif g_acl_services.has_key(j) and g_acl_services[j].has_key(i):
                g_acl_services[i][j] = g_acl_services[j][i]
            else:
                # give 1/4 probability for connection
                g_acl_services[i][j] = (random.randrange(0, 3) == 0)


    g_num_hosts_per_router = ports_per_leaf_router - g_router_replication
    g_num_leaf_routers = 1 << int(math.ceil(math.log(nodes_per_datacenter / g_num_hosts_per_router, 2)))
    g_router_branching = 1 << int(math.floor(math.log((ports_per_router - g_router_replication) / g_router_replication, 2)))
    height_datacenter = int(math.ceil(math.log(g_num_leaf_routers, g_router_branching)))

    g_private_ip = dotted_ip_to_int('10.0.0.0')
    g_bits_leaf_ips = int(math.ceil(math.log(g_num_hosts_per_router * g_num_ips_per_host, 2)))
    g_bits_datacenter = height_datacenter * int(math.log(g_router_branching, 2)) + g_bits_leaf_ips

    # arbitrary public IP
    g_public_ip = random.choice([random.randrange(dotted_ip_to_int('3.0.0.0'), dotted_ip_to_int('9.254.254.0'), 256),
                                 random.randrange(dotted_ip_to_int('11.0.0.0'), dotted_ip_to_int('126.254.254.0'), 256),
                                 random.randrange(dotted_ip_to_int('128.0.0.0'), dotted_ip_to_int('171.254.254.0'), 256),
                                 random.randrange(dotted_ip_to_int('173.0.0.0'), dotted_ip_to_int('191.254.254.0'), 256),
                                 random.randrange(dotted_ip_to_int('193.0.0.0'), dotted_ip_to_int('202.254.254.0'), 256)])
    assert (g_public_ip & dotted_ip_to_int('255.255.255.0')) == g_public_ip

    g_public_port = random.randrange(20, 500)

    # assign internal IPs to services
    for i in range(0, g_num_services):
        g_services_ips[i] = []

    ip = g_private_ip
    for i in range(0, g_num_datacenters):
        services = list(g_services_datacenter[i])
        random.shuffle(services)

        num_dt_services = len(services)
        assert is_power_two(num_dt_services)

        s_per_host = 1 << int(math.floor(math.log(random.randrange(1, services_per_host), 2)))
        s_per_host = min(s_per_host, num_dt_services)
        assert s_per_host <= services_per_host

        num_partitions = int(math.ceil(num_dt_services / s_per_host))
        assert num_partitions > 0
        assert is_power_two(num_partitions)

        bits_partition = int(math.log(num_partitions, 2))
        assert bits_partition <= g_bits_datacenter

        bits_partition = g_bits_datacenter - bits_partition
        ip_partition = ip
        ip_inc = 1 << bits_partition
        service_idx = 0

        for j in range(0, num_partitions):
            for w in range(0, s_per_host):
                g_services_ips[services[service_idx]].append((ip_partition, bits_partition))
                service_idx += 1
            ip_partition += ip_inc

        ip += 1 << g_bits_datacenter
        assert ip == ip_partition


    print "Datacenter tree height: %d" % height_datacenter
    print "Public services IP: %s" % int_to_dotted_ip(g_public_ip)
    print "Public TCP port: %d" % g_public_port
    print "Number of hosts per leaf router: %d" % g_num_hosts_per_router
    print "Number of leaf routers: %d" % g_num_leaf_routers
    print "Number of bits of leaf IPs: %d" % g_bits_leaf_ips
    print "Number of bits per datacenter: %d" % g_bits_datacenter
    print "Router branching: %d" % g_router_branching

    print
    print "Services per Datacenter:"
    for i in range(0, g_num_datacenters):
        s = list(g_services_datacenter[i])
        s.sort()
        print "Datacenter %d: #%d %s" % (i, len(s), s)

    print
    print "Services' IPs:"
    for i in range(0, g_num_services):
        ips = []
        for (ip, bits) in g_services_ips[i]:
            ips.append(int_to_dotted_ip(ip) + "/" + str(32-bits))
        print "Service %d: #%d %s" % (i, len(ips), ", ".join(ips))

    print
    print "ACL Matrix:"
    for i in range(0, g_num_services+1):
        sys.stdout.write(str(i) + ': ')
        for j in range(0, g_num_services+1):
            if g_acl_services[i][j]:
                sys.stdout.write('1')
            else:
                sys.stdout.write('0')
        print

    print
    ip = g_private_ip
    for i in range(0, g_num_datacenters):
        print "Datacenter %d: %s (port %d)" % (i, int_to_dotted_ip(ip), datacenter_port(i))
        gen_datacenter(i, ip, g_bits_datacenter, height_datacenter, [datacenter_port(i)])
        ip += 1 << g_bits_datacenter

    gen_backbone_topology()
    print
    NTF.save_object_to_file('output.tf')


if __name__ == "__main__":
    main()
