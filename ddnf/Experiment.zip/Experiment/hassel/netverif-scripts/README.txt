Scripts in this package:
 - cloud-tf-gen.py: Cloud-like topology generator
 - collect_stats.py: Collect statistics from .tf files
 - dot.py: .tf -> .dot converter
 - dot-routers.py: .tf -> .dot converter (outputs only routers)
 - horn.py: .tf -> .smt2 (Horn clauses)
 - smt-bv-iter.py: .tf -> SMT encoding + iterative All SAT computation


Note: most scripts require Z3Py, which is available from http://z3.codeplex.com/

Note 2: It is advised to run the scripts with 'python -O' for performance
reasons.
