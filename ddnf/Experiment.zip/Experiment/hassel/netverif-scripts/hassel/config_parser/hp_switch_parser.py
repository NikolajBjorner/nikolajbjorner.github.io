'''
Created on Jul 6, 2011

@author: peymankazemian
'''

class HPSwitch():
    
    def __init__(self, switch_id):   
        self.switch_id = switch_id
        
        
    def read_config_file(self, file):
        pass
        