#!/usr/bin/env python

'''
Copyright (c) 2013-2014, Nuno Lopes
All rights reserved.
'''

import sys
sys.path.append('C:\\z3\\bin')
sys.path.append('hassel')

import os, time, argparse
from z3 import *
from headerspace.tf import TF
from headerspace.hs import *

do_dep_compression = False
do_simp_deps = False
add_gbl_rid = False

def my_simplify(fml):
    t1 = Tactic('simplify')
    t2 = Tactic('ctx-solver-simplify')
    t = Then(t1, t2)
    return t.apply(fml)[0].as_expr()

def get_decl(port, vars, fp):
  sorts = [v.sort() for v in vars] + [BoolSort()]
  f = Function("R_%d" % port, sorts)
  fp.register_relation(f)
  return f(vars)

next_decl_id = 0
def get_tmp_decl(vars, fp):
  global next_decl_id
  sorts = [v.sort() for v in vars] + [BoolSort()]
  f = Function("T_%d" % next_decl_id, sorts)
  fp.register_relation(f)
  next_decl_id += 1
  return f(vars)

def mkOr(l):
  return Or(l) if len(l) > 0 else BoolVal(False)

def gen_match_constraint(mask, match, offset, size, var):
    mask = ~int(mask[offset*8:(offset+size)*8], 2)
    match = int(match[offset*8:(offset+size)*8], 2)
    return ((var|mask) == (match|mask))

def convert_match(match, packet_vars):
    if match == None:
        return BoolVal(True)

    [ip_src, ip_dst, tcp_src, tcp_dst, vlan, ip_proto, tcp_ctrl] = packet_vars
    [rule_mask, rule_match] = byte_array_wildcard_to_mask_match_strings(match)
    rule = []
    rule.append(gen_match_constraint(rule_mask, rule_match, 0, 2, vlan))
    rule.append(gen_match_constraint(rule_mask, rule_match, 2, 4, ip_src))
    rule.append(gen_match_constraint(rule_mask, rule_match, 6, 4, ip_dst))
    rule.append(gen_match_constraint(rule_mask, rule_match, 10, 1, ip_proto))
    rule.append(gen_match_constraint(rule_mask, rule_match, 11, 2, tcp_src))
    rule.append(gen_match_constraint(rule_mask, rule_match, 13, 2, tcp_dst))
    rule.append(gen_match_constraint(rule_mask, rule_match, 15, 1, tcp_ctrl))
    return And(rule)

def gen_rw_constraint(rw_match, rw_mask, mask, offset, size, var, varp):
    rw_match = int(rw_match[offset*8:(offset+size)*8], 2)
    rw_mask = int(rw_mask[offset*8:(offset+size)*8], 2)
    mask = int(mask[offset*8:(offset+size)*8], 2)
    return ((varp & rw_mask) == ((var & mask) | rw_match))

def convert_rewrite(rw_match, mask, packet_vars, packet_vars_next):
    [ip_src, ip_dst, tcp_src, tcp_dst, vlan, ip_proto, tcp_ctrl] = packet_vars
    [ip_src_next, ip_dst_next, tcp_src_next, tcp_dst_next, vlan_next, ip_proto_next, tcp_ctrl_next] = packet_vars_next

    [rw_mask, rw_match] = byte_array_wildcard_to_mask_match_strings(rw_match)
    mask = byte_array_to_hs_string(mask)

    rule = []
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 0, 2, vlan, vlan_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 2, 4, ip_src, ip_src_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 6, 4, ip_dst, ip_dst_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 10, 1, ip_proto, ip_proto_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 11, 2, tcp_src, tcp_src_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 13, 2, tcp_dst, tcp_dst_next))
    rule.append(gen_rw_constraint(rw_match, rw_mask, mask, 15, 1, tcp_ctrl, tcp_ctrl_next))
    return rule


def only_one_bit_diff(a, b):
  index = None
  for i in range(len(a)):
    for j in range(4):
      if byte_array_get_bit(a, i, j) == byte_array_get_bit(b, i, j):
        continue
      if index != None:
        return False
      index = (i, j)
  return index

def my_hs_compress(l):
  remove = set([])
  for i in range(len(l)):
    for j in range(i+1, len(l)):
      diff = only_one_bit_diff(l[i], l[j])
      if diff != False:
        (byte, bit) = diff
        l[i] = bytearray(l[i])
        byte_array_set_bit(l[i], byte, bit, 0x03)
        remove |= set([j])

  if remove:
    return my_hs_compress([l[i] for i in range(len(l)) if i not in remove])
  return l


deps_cache = {}
def get_affected_fml(deps, packet_vars):
  if deps_cache.has_key(deps):
    return deps_cache[deps]

  if len(deps) <= 1 or not do_simp_deps:
    f = [match_rule[r] for r in deps]
  else:
    HS = headerspace(int(128*2/8))
    for d in deps:
      HS.add_hs(match_rule_ba[d])
    HS.compress()
    f = [convert_match(m, packet_vars) for m in my_hs_compress(HS.hs_list)]

  deps_cache[deps] = f = my_simplify(Not(mkOr(f)))
  return f

# src port -> rule*
rules = {}

# rule id -> Z3 match fml
match_rule = {}

# rule id -> match byte array
match_rule_ba = {}

def import_rules(rtr_name, input_path, packet_vars, packet_vars_cpy, packet_vars_next):
    global rules, match_rule, match_rule_ba

    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)

    for rule in tf.rules:
        match = simplify(convert_match(rule["match"], packet_vars))
        match_rule[rule["id"]] = match
        match_rule_ba[rule["id"]] = rule["match"]

        if rule["out_ports"] == []:
            continue

        for src in rule["in_ports"]:
            if rule["action"] == "fwd" or rule["action"] == "link":
                fml = match
                vars_next = packet_vars_cpy
            else:
                assert rule["action"] == "rw"
                rw = convert_rewrite(rule["rewrite"], rule["mask"], packet_vars, packet_vars_next)
                fml = simplify(And(match, And(rw)))
                vars_next = packet_vars_next

            if not rules.has_key(src):
                rules[src] = []
            rules[src] += [(rule, fml, vars_next)]

def compare_map_vals(map):
  first = True
  for d in map.itervalues():
    if first:
      dcmp = d
      first = False
    elif d != dcmp:
      return False, None
  return True, dcmp

def create_dep_fmls(deps, fp, packet_vars, src):
  src_decl = get_decl(src, packet_vars, fp)
  rule_deps = {}
  nonempty_deps = {}

  if do_dep_compression == False:
    for r, d in deps.iteritems():
      rule_deps[r] = (get_affected_fml(d, packet_vars), src_decl)
    return rule_deps

  # ignore rules without deps right away
  for r,d in deps.iteritems():
    if len(d) == 0:
      rule_deps[r] = (BoolVal(True), src_decl)
    else:
      nonempty_deps[r] = d

  if len(nonempty_deps) == 1:
    for r, d in nonempty_deps.iteritems():
      rule_deps[r] = (get_affected_fml(d, packet_vars), src_decl)

  if len(nonempty_deps) <= 1:
    return rule_deps

  # if all deps are equal, create a new clause
  allequal, eqdeps = compare_map_vals(nonempty_deps)
  if allequal:
    new_decl = get_tmp_decl(packet_vars, fp)
    for r in nonempty_deps.iterkeys():
      rule_deps[r] = (BoolVal(True), new_decl)

    fml = my_simplify(get_affected_fml(eqdeps, packet_vars))
    fp.rule(new_decl, [src_decl, fml])
    return rule_deps

  # now handle the complex case
  # analyze the cross-product of the intersections
  cross_deps = {}

  for r, d in nonempty_deps.iteritems():
    for r2, d2 in nonempty_deps.iteritems():
      if r >= r2:
        continue
      cross_deps['%s_%s' % (r, r2)] = d & d2

  # create a new clause for the prefix if it's common to all pairs
  allequal, eqdeps = compare_map_vals(cross_deps)
  if allequal:
    new_decl = get_tmp_decl(packet_vars, fp)
    for r, d in nonempty_deps.iteritems():
      rule_deps[r] = (get_affected_fml(d - eqdeps, packet_vars), new_decl)

    fp.rule(new_decl, [src_decl, my_simplify(get_affected_fml(eqdeps, packet_vars))])
    return rule_deps

  print 'dep compression potentially not optimal..'
  for r, d in nonempty_deps.iteritems():
    rule_deps[r] = (get_affected_fml(d, packet_vars), src_decl)

  """
  TODO
  print
  for k, d in cross_deps.iteritems():
      print "%s : %s" % (k, d)
  exit()
  """

  return rule_deps


# make expr that marks when a packet has gone through this rule
def get_gbl_id(rule, dst, packet_vars, packet_vars_next, vars_next):
  global gbl_rule_ids, add_gbl_rid
  if not add_gbl_rid:
    return True, vars_next

  var = packet_vars[-1]
  varp = packet_vars_next[-1]
  if gbl_rule_ids.has_key((rule["id"], dst)):
    return varp == (var | (1 << gbl_rule_ids[(rule["id"], dst)])), vars_next
  else:
    return True, vars_next[:-1] + [packet_vars[-1]]


def generate_horn(packet_vars, packet_vars_next, fp):
    for src, rules_src in rules.iteritems():
        deps = {}
        for rule, fml, vars_next in rules_src:
            d = frozenset([r["id"] for (r, h, ports) in rule["affected_by"] if src in ports])
            deps[rule["id"]] = d

        deps = create_dep_fmls(deps, fp, packet_vars, src)

        for rule, fml, vars_next in rules_src:
            assert src in rule["in_ports"]

            aff, src_decl = deps[rule["id"]]
            if not is_true(aff):
                fml = my_simplify(And(fml, aff))
                if is_false(fml):
                    continue

            for dst in rule["out_ports"]:
              f,vs = get_gbl_id(rule, dst, packet_vars, packet_vars_next, vars_next)
              fp.rule(get_decl(dst, vs, fp), [src_decl, simplify(And(fml, f))])


def main():
    rtr_names = [
                 "bbra_rtr",
                 "bbrb_rtr",
                 "boza_rtr",
                 "bozb_rtr",
                 "coza_rtr",
                 "cozb_rtr",
                 "goza_rtr",
                 "gozb_rtr",
                 "poza_rtr",
                 "pozb_rtr",
                 "roza_rtr",
                 "rozb_rtr",
                 "soza_rtr",
                 "sozb_rtr",
                 "yoza_rtr",
                 "yozb_rtr",
                 "backbone_topology"
                 ]

    parser = argparse.ArgumentParser(description='Convert tf files into Horn clauses')
    parser.add_argument('--input_path', dest='input_path', required=False)
    parser.add_argument('--file', dest='file', required=False)
    parser.add_argument('--output', dest='output', required=False, type=str, default='output.smt2')
    parser.add_argument('--compress-deps', dest='compress_deps', required=False, type=bool, default=False)
    parser.add_argument('--simp-deps', dest='simp_deps', required=False, type=bool, default=False)
    parser.add_argument('--add-rid', dest='add_rid', required=False, type=bool, default=False)
    args = parser.parse_args()

    if args.input_path != None:
        input_path = args.input_path
    else:
        input_path = ''

    if args.file != None:
        rtr_names = [args.file]

    global do_dep_compression, do_simp_deps, add_gbl_rid
    do_dep_compression = args.compress_deps
    do_simp_deps = args.simp_deps
    add_gbl_rid = args.add_rid

    fp = Fixedpoint()

    vlan     = BitVec('vlan', 16)
    ip_src   = BitVec('ip_src', 32)
    ip_dst   = BitVec('ip_dst', 32)
    ip_proto = BitVec('ip_proto', 8)
    tcp_src  = BitVec('tcp_src', 16)
    tcp_dst  = BitVec('tcp_dst', 16)
    tcp_ctrl = BitVec('tcp_ctrl', 8)

    vlan_next     = BitVec('vlan_next', 16)
    ip_src_next   = BitVec('ip_src_next', 32)
    ip_dst_next   = BitVec('ip_dst_next', 32)
    ip_proto_next = BitVec('ip_proto_next', 8)
    tcp_src_next  = BitVec('tcp_src_next', 16)
    tcp_dst_next  = BitVec('tcp_dst_next', 16)
    tcp_ctrl_next = BitVec('tcp_ctrl_next', 8)

    packet_vars = [ip_src, ip_dst, tcp_src, tcp_dst, vlan, ip_proto, tcp_ctrl]
    packet_vars_cpy = list(packet_vars)
    packet_vars_next = [ip_src_next, ip_dst_next, tcp_src_next, tcp_dst_next, vlan_next, ip_proto_next, tcp_ctrl_next]

    for rtr_name in rtr_names:
        import_rules(rtr_name, input_path, packet_vars, packet_vars_cpy, packet_vars_next)


    global gbl_rule_ids
    gbl_rule_ids = {}

    if add_gbl_rid:
      next_id = 0
      seen_rules = {}

      for src, rules_src in rules.iteritems():
        for rule, fml, vars_next in rules_src:
          ports = rule["out_ports"]
          if len(ports) <= 1 or seen_rules.has_key(rule["id"]):
            continue
          seen_rules[rule["id"]] = True

          for i in range(len(ports)-1):
            gbl_rule_ids[(rule["id"], ports[i])] = next_id
            next_id += 1

      bits_gbl_id = int(ceil(next_id/32.0) * 32)
      packet_vars += [BitVec('rids', bits_gbl_id)]
      packet_vars_next += [BitVec('rids_next', bits_gbl_id)]
      packet_vars_cpy += [packet_vars_next[-1]]
      print "Num rule ids: %d (%d bits)" % (next_id, bits_gbl_id)

    for v in packet_vars + packet_vars_next:
      fp.declare_var(v)

    generate_horn(packet_vars, packet_vars_next, fp)

    output_file = open(args.output, 'w')
    output_file.write("%s" % fp)
    output_file.write("(declare-var vlan (_ BitVec 16))\n")
    output_file.write("(declare-var ip_src (_ BitVec 32))\n")
    output_file.write("(declare-var ip_dst (_ BitVec 32))\n")
    output_file.write("(declare-var ip_proto (_ BitVec 8))\n")
    output_file.write("(declare-var tcp_src (_ BitVec 16))\n")
    output_file.write("(declare-var tcp_dst (_ BitVec 16))\n")
    output_file.write("(declare-var tcp_ctrl (_ BitVec 8))\n")

    if add_gbl_rid:
      output_file.write("(declare-var rids (_ BitVec %d))\n" % bits_gbl_id)
      extra_var = " rids"
    else:
      extra_var = ""

    output_file.write("(rule (R_%d ip_src ip_dst tcp_src tcp_dst vlan ip_proto tcp_ctrl%s))\n" % (1110002, extra_var))
    output_file.write("(query (R_%d ip_src ip_dst tcp_src tcp_dst vlan ip_proto tcp_ctrl%s))\n" % (1220009, extra_var))
    output_file.close()

if __name__ == "__main__":
    main()
