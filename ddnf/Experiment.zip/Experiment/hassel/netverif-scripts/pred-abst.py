#!/usr/bin/env python

'''
Copyright (c) 2013-2014, Nuno Lopes
All rights reserved.
'''

import sys
sys.path.append('C:\\z3\\bin')
sys.path.append('hassel')

import os, time, argparse
from headerspace.tf import TF
from headerspace.hs import *

do_dep_compression = False
do_simp_deps = False
add_gbl_rid = False

def count_rulesets(rtr_name, input_path):
    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)
    in_ports = {}

    for rule in tf.rules:
        for p in rule["in_ports"]:
            if p not in in_ports:
                in_ports[p] = 1

    return len(in_ports)


def import_rules(rtr_name, input_path):

    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)
    in_ports = {}

    for rule in tf.rules:
        for p in rule["in_ports"]:
            if p not in in_ports:
                in_ports[p] = 1


    for inp in in_ports:
        num_out = 1
        num_rules = 0
        out_ports = {}
        for rule in tf.rules:
            if inp in rule["in_ports"]:
                for p in rule["out_ports"]:
                    if p not in out_ports:
                        out_ports[p] = num_out
                        num_out += 1
                if rule["out_ports"]:
                    if rule["action"] == "fwd":
                        m = rule["match"]
                        if m:
                            num_rules += 1

        print num_rules, num_out

        for rule in tf.rules:
            if inp not in rule["in_ports"]:
                continue
            ports = rule["out_ports"]
            if not ports:
                continue
            port = ports[0] # just pick first port for simplicity.

            if rule["action"] == "fwd":
                m = rule["match"]
                if m:
                    print out_ports[port], byte_array_to_hs_string(m)




def main():
    rtr_names = [
                 "bbra_rtr",
                 "bbrb_rtr",
                 "boza_rtr",
                 "bozb_rtr",
                 "coza_rtr",
                 "cozb_rtr",
                 "goza_rtr",
                 "gozb_rtr",
                 "poza_rtr",
                 "pozb_rtr",
                 "roza_rtr",
                 "rozb_rtr",
                 "soza_rtr",
                 "sozb_rtr",
                 "yoza_rtr",
                 "yozb_rtr"
                 ]

    parser = argparse.ArgumentParser(description='Convert tf files into Horn clauses')
    parser.add_argument('--input_path', dest='input_path', required=False)
    parser.add_argument('--file', dest='file', required=False)
    parser.add_argument('--output', dest='output', required=False, type=str, default='output.smt2')
    args = parser.parse_args()

    if args.input_path != None:
        input_path = args.input_path
    else:
        input_path = 'C:/QnA/Experiment/hassel/stanford/network'

    if args.file != None:
        rtr_names = [args.file]

    num_rulesets = 0
    for rtr_name in rtr_names:
        num_rulesets += count_rulesets(rtr_name, input_path)

    print 128, num_rulesets
    for rtr_name in rtr_names:
        import_rules(rtr_name, input_path)

if __name__ == "__main__":
    main()
