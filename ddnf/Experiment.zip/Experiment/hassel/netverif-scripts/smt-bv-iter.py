#!/usr/bin/env python

'''
Copyright (c) 2013, Nuno Lopes
All rights reserved.
'''

import sys
sys.path.append('C:\\z3\\bin')
sys.path.append('hassel')

import os, time, argparse, math
from z3 import *
from headerspace.tf import TF
from headerspace.hs import byte_array_wildcard_to_mask_match_strings, byte_array_to_hs_string

minimize_QX = False
minimize_qx_1 = True


def inc(map, key, val):
  if map.has_key(key):
    map[key] += val
  else:
    map[key] = val

def print_table(t, name, suffix):
  if len(t) == 0:
    return

  print '\n%s\n========' % name
  maxl = max([len(k) for k, v in t.iteritems()]) + 2
  for k, v in t.iteritems():
    print "%s:%s%s%s" % (k, ''.ljust(maxl-len(k)), v, suffix)

ticks = {}
def tick(n):
  inc(ticks, n, 1)

def print_ticks():
  print_table(ticks, 'Events', '')

watches = {}
def stop_watch(n, start):
  inc(watches, n, time.clock() - start)

def print_watches():
  print_table(watches, 'Time', 's')

def print_stats():
  print_ticks()
  print_watches()


# step x port -> (reach, var)
formulas = {}

aux_formulas = [BoolVal(True)]
aux_mux_vars = []


def slow_fml_simplify(fml):
    t1 = With(Tactic('simplify'), push_ite=True)
    t2 = Tactic('propagate-values')
    t3 = Tactic('ctx-simplify')
    #t = Then(t1, t2, t3, t1) -- t3 is too slow
    t = Then(t1, t2, t1)
    return t.apply(fml)[0].as_expr()

def convert_match(match, var):
    if match == None:
        return True

    [mask, match] = byte_array_wildcard_to_mask_match_strings(match)
    mask = ~int(mask, 2)
    match = int(match, 2)
    if mask == 0:
        return var == match
    return ((var|mask) == (match|mask))

next_rwvar_id = 0

def convert_rewrite(rw_match, mask, var):
    [rw_mask, rw_match] = byte_array_wildcard_to_mask_match_strings(rw_match)
    rw_mask = int(rw_mask, 2)
    rw_match = int(rw_match, 2)
    mask = int(byte_array_to_hs_string(mask), 2)
    if rw_mask == ((1 << 128) - 1):
        return (var & mask) | rw_match

    global aux_formulas, next_rwvar_id
    varp = BitVec('rwvar_' + `next_rwvar_id`, 128)
    next_rwvar_id += 1
    aux_formulas += [(varp & rw_mask) == ((var & mask) | rw_match)]
    return varp

in_rules = {}

def add_rule(src, dst, guard, var, var_p, rule):
    global in_rules
    if not in_rules.has_key(dst):
        in_rules[dst] = []
    in_rules[dst].append((src, guard, var, var_p, rule))

def aggregate_fmls_r(src, dst, fs, seen_rules):
    (guard, var, var_p, rule) = fs[0]
    for (r,h,ports) in rule["affected_by"]:
        if r["id"] in seen_rules or src not in ports:
            continue
        guard = And(guard, Not(convert_match(r["match"], var)))

    tail = fs[1:]
    if tail == []:
        return var_p, [guard]
    seen_rules.append(rule["id"])

    f,guards = aggregate_fmls_r(src, dst, tail, seen_rules)
    guards.append(guard)
    return If(guard, var_p, f), guards

def build_nondet_choice_r(fs, muxs):
    tail = fs[1:]
    if tail == []:
        assert muxs == []
        return fs[0]
    return If(muxs[0], fs[0], build_nondet_choice_r(tail, muxs[1:]))

def build_nondet_choice(fmls, reach, step, port):
    global aux_formulas, aux_mux_vars

    fs = []
    muxs = []
    last_idx = len(fmls)-1
    for f, guards in fmls[:last_idx]:
        mux = FreshBool('mux_' + `port` + '_' + `step`)
        muxs.append(mux)
        aux_mux_vars.append(mux)
        aux_formulas.append(simplify(Implies(mux, Or(guards))))
        fs.append(f)

    fs.append(fmls[last_idx][0])
    aux_formulas.append(simplify(Implies(And(reach, Not(Or(muxs))),
                                         Or(fmls[last_idx][1]))))
    return simplify(build_nondet_choice_r(fs, muxs))

def aggregate_fmls(step):
    global in_rules, formulas
    formulas[step] = {}
    for dst, fs in in_rules.iteritems():
        map = {}
        for src, guard, var, var_p, rule in fs:
            if not map.has_key(src):
                map[src] = []
            map[src].append((guard, var, var_p, rule))

        fmls = []
        all_guards = []
        for src, fs in map.iteritems():
            f, guards = aggregate_fmls_r(src, dst, fs, [])
            all_guards.extend(guards)
            fmls.append((simplify(f), guards))

        reach_p = simplify(Or(all_guards))
        if len(fmls) == 1:
            formulas[step][dst] = (reach_p, fmls[0][0])
        else:
            formulas[step][dst] = (reach_p, build_nondet_choice(fmls, reach_p, step, dst))
    in_rules = {}


# src port -> rule*
rules = {}

def import_rules(rtr_name, input_path):
    global rules
    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)

    for rule in tf.rules:
        for src in rule["in_ports"]:
            if not rules.has_key(src):
                rules[src] = []
            rules[src].append(rule)

def generate_fmls(step, reach_port, last_step):
    global rules, formulas

    for (src, (reach, var)) in formulas[step-1].iteritems():
        if not rules.has_key(src):
            continue

        for rule in rules[src]:
            assert src in rule["in_ports"]

            # check for useless dead-ends
            useless = True
            for dst in rule["out_ports"]:
                if dst == reach_port or (not last_step and rules.has_key(dst)):
                    useless = False
                    break
            if useless:
                continue

            match_clause = convert_match(rule["match"], var)
            guard = simplify(And(reach, match_clause))

            if is_false(guard):
                continue

            if rule["action"] == "fwd" or rule["action"] == "link":
                var_p = var
            else:
                assert rule["action"] == "rw"
                var_p = convert_rewrite(rule["rewrite"], rule["mask"], var)

            for dst in rule["out_ports"]:
                # skip useless dead-ends
                if dst == reach_port or (not last_step and rules.has_key(dst)):
                    add_rule(src, dst, guard, var, var_p, rule)
    aggregate_fmls(step)

def get_mux_var_values(model):
    global aux_mux_vars
    result = []
    for var in aux_mux_vars:
        val = model[var]
        if val != None:
            result += [var if is_true(val) else Not(var)]
    return result

def blast_vector(x, fs):
    sz = x.sort().size()
    vars = []
    for i in range(sz):
        x_i = Bool("%s_%i" % (x, i))
        fs += [x_i == (Extract(i,i,x) == BitVecVal(1,1))]
        vars += [x_i]
    return vars

def get_value(bit, x):
    return x if bit else Not(x)

def get_id(x):
    return Z3_get_ast_id(x.ctx.ref(),x.as_ast())

def get_vars(set, list):
    return [v for v in list if get_id(v) in set]

def reduce_set(name, s, s2):
    l = len(s)
    s &= s2
    if len(s) < l:
        tick('reduce_' + name)

def test_hyp(s, f, core, WL, aux):
    if s.check(f) != unsat:
        return False

    newcore = s.unsat_core()
    # fast-path, since get_id() is very slow
    if len(f) == len(newcore):
        return True

    newcore = set([get_id(x) for x in newcore])
    reduce_set('core', core, newcore)
    reduce_set('WL', WL, newcore)
    reduce_set('auxv', aux, newcore)
    return True


# linear, left-to-right, core minimization
def minimize_core(s, vars, aux_values, map_vars):
  core    = set([])
  WL      = set([get_id(x) for x in vars])
  aux_ids = set([get_id(x) for x in aux_values])
  extra_fmls = []

  while len(WL) > 0:
    id = list(WL)[0]
    WL -= set([id])

    fcore = get_vars(WL | core, vars) + extra_fmls
    f = fcore + get_vars(aux_ids, aux_values)

    if test_hyp(s, f, core, WL, aux_ids):
        continue

    if map_vars == None:
        core |= set([id])
        continue

    v2, eq = map_vars[id]
    aux_ids2 = aux_ids - set([get_id(v2)])
    f = fcore + [eq] + get_vars(aux_ids2, aux_values)

    if test_hyp(s, f, core, WL, aux_ids2):
        aux_ids = aux_ids2
        extra_fmls += [eq]
    else:
        core |= set([id])

  if __debug__:
      f = get_vars(core, vars) + extra_fmls + get_vars(aux_ids, aux_values)
      assert test_hyp(s, f, set([]), set([]), set([]))

  return core


def minimize_core_qx(s, core, assignment, vars, aux_ids, aux_vars, map_vars,
                     extra_fmls, WL, has_support):
    fcore = get_vars(core, vars) + extra_fmls
    f = fcore + get_vars(aux_ids, aux_vars)

    if has_support:
        if test_hyp(s, f, core, WL, aux_ids):
            return set([])

        # now test with equality injection
        if map_vars != None:
            aux_ids2 = set(aux_ids)
            eqs = []
            for v in assignment:
                v2, eq = map_vars[v]
                aux_ids2 -= set([get_id(v2)])
                eqs += [eq]

            f = fcore + eqs + get_vars(aux_ids2, aux_vars)
            if test_hyp(s, f, core, WL, aux_ids2):
                aux_ids &= aux_ids2
                extra_fmls += eqs
                return set([])

    if len(assignment) == 1:
        return assignment

    assignment = list(assignment)
    if minimize_qx_1:
        assign1 = set([assignment[2*i] for i in range(len(assignment)/2 + 1) if 2*i < len(assignment)])
        assign2 = set([assignment[2*i+1] for i in range(len(assignment)/2)])
    else:
        assign1 = set([assignment[i] for i in range(len(assignment)/2)])
        assign2 = set([assignment[i] for i in range(len(assignment)/2, len(assignment))])
    assert (assign1 | assign2) == set(assignment)
    assert len(assign1 & assign2) == 0

    assign2 = minimize_core_qx(s, core | assign1, assign2, vars, aux_ids, aux_vars,
                               map_vars, extra_fmls, assign1, len(assign1) > 0)
    assign1 = minimize_core_qx(s, core | assign2, assign1, vars, aux_ids, aux_vars,
                               map_vars, extra_fmls, assign2, len(assign2) > 0)

    if __debug__:
        core = core | assign1 | assign2
        f = get_vars(core, vars) + extra_fmls + get_vars(aux_ids, aux_vars)
        assert test_hyp(s, f, set([]), set([]), set([]))

    return assign1 | assign2


def minimize_assignment(s, assignment, extra_assignments, map_vars, aux_values):
    if s.check(assignment + extra_assignments + aux_values) != unsat:
        raise Exception('Model not UNSAT')

    assignment_ids = [get_id(x) for x in assignment]
    core = []
    aux_values = []
    for x in list(s.unsat_core()):
        if get_id(x) in assignment_ids:
            core += [x]
        else:
            aux_values += [x]

    if minimize_QX:
        return minimize_core_qx(s, set([]), set([get_id(x) for x in core]), core,
                                set([get_id(x) for x in aux_values]), aux_values,
                                map_vars, [], set([]), False)
    return minimize_core(s, core, aux_values, map_vars)

def extract_and_generalize_sol(model, vars, vars_blasted, equality_vars, sneg):
    var_value  = model[vars[0]].as_long()
    aux_values = get_mux_var_values(model)
    assignment = [get_value(var_value & (1 << i), vars_blasted[0][i]) for i in range(len(vars_blasted[0]))]
    extra_assignments = []
    for v,v_blasted in zip(vars[1:], vars_blasted[1:]):
      val = model[v].as_long()
      extra_assignments += [get_value(val & (1 << i), v_blasted[i])
                            for i in range(len(v_blasted))]

    if len(equality_vars) > 0:
        assert len(vars) == 2
        map_vars = {}
        i = 0
        for v, v2 in zip(assignment, extra_assignments):
            if (is_not(v) and is_not(v2)) or not (is_not(v) or is_not(v2)):
                map_vars[get_id(v)] = (v2, equality_vars[i])
            else:
                map_vars[get_id(v)] = (v2, Not(equality_vars[i]))
            i += 1
    else:
        assert extra_assignments == []
        map_vars = None

    new_assignment = minimize_assignment(sneg, assignment, extra_assignments,
                                         map_vars, aux_values)

    assignment = [ get_id(x) for x in assignment ]

    mask = 2**128 - 1
    for i in range(0, 128):
        if assignment[i] not in new_assignment:
            mask = mask & ~(1 << i)
    return (var_value, mask)

def print_soln(f, mask):
    sl = ""
    for i in range(128):
        sh = (1 << i)
        if (sh & mask & f):
            sl += "1"
        elif (sh & mask):
            sl += "0"
        else:
            sl += "*"
    return sl

def solver_to_smtlib(s):
    a = s.assertions()
    size = len(a) - 1
    _a = (Ast * size)()
    for k in range(size):
        _a[k] = a[k].as_ast()
    return Z3_benchmark_to_smtlib_string(a[size].ctx_ref(), "network verification", "QF_BV", "unknown", "", size, _a,  a[size].as_ast())


def main():
    rtr_names = [
                 "bbra_rtr",
                 "bbrb_rtr",
                 "boza_rtr",
                 "bozb_rtr",
                 "coza_rtr",
                 "cozb_rtr",
                 "goza_rtr",
                 "gozb_rtr",
                 "poza_rtr",
                 "pozb_rtr",
                 "roza_rtr",
                 "rozb_rtr",
                 "soza_rtr",
                 "sozb_rtr",
                 "yoza_rtr",
                 "yozb_rtr",
                 "backbone_topology"
                 ]

    parser = argparse.ArgumentParser(description='Convert tf files into SMT-lib2 (BV theory)')
    parser.add_argument('--input_path', dest='input_path', required=False)
    parser.add_argument('--file', dest='file', required=False)
    parser.add_argument('--ttl', dest='ttl', required=True, type=int)
    parser.add_argument('--seed', dest='seed', required=True, type=int)
    parser.add_argument('--reach', dest='reach', required=True, type=int)
    parser.add_argument('--allsat-in', dest='allsat_in', required=False, default=False, type=bool)
    parser.add_argument('--min-algo', dest='min_algo', required=False, type=str)
    args = parser.parse_args()

    ttl = int(args.ttl)
    allsat_in = args.allsat_in

    if ttl < 1:
        raise Exception("TTL must be >= 1")

    if args.input_path != None:
        input_path = args.input_path
    else:
        input_path = ''

    if args.file != None:
        rtr_names = [args.file]
    else:
        # In Stanford benchmarks each router has 3 transform steps + 1 routing step
        ttl *= 4

    global minimize_QX, minimize_qx_1
    if args.min_algo != None:
        if args.min_algo == 'qx1':
            minimize_QX = True
            minimize_qx_1 = True
        elif args.min_algo == 'qx2':
            minimize_QX = True
            minimize_qx_1 = False
        elif args.min_algo == 'linear':
            minimize_QX = False
        else:
            raise Exception('Unknown minimization algorithm: ' + args.min_algo)

    seed_port  = args.seed
    reach_port = args.reach

    sys.setrecursionlimit(10000)

    global formulas, aux_formulas
    prep_start = time.clock()

    # generate initial input
    input = BitVec('input', 128)
    formulas[0] = {}
    formulas[0][seed_port] = (True, input)

    for rtr_name in rtr_names:
        import_rules(rtr_name, input_path)

    for step in range(1, ttl):
        sys.stdout.write("\rstep %d" % step)
        generate_fmls(step, reach_port, step == ttl-1)
    print ""

    output = BitVec('output', 128)
    fs = [BoolVal(False)]
    for (step, map) in formulas.iteritems():
        for (port, (reach, val)) in map.iteritems():
            if port == reach_port:
                if allsat_in:
                    fs.append(reach)
                else:
                    fs.append(And(reach, output == val))

    fs = simplify(And(Or(fs), And(aux_formulas)))

    #s = Tactic('qfbv').solver()
    s = SimpleSolver()
    s.assert_exprs(slow_fml_simplify(fs))

    sneg = SimpleSolver()
    fs = [Not(fs)]

    equality_vars = []
    if allsat_in:
        vars = [input]
        vars_blast = [blast_vector(input, fs)]
    else:
        vars       = [output, input]
        vars_blast = [blast_vector(output, fs), blast_vector(input, fs)]
        for v,v2 in zip(vars_blast[0], vars_blast[1]):
            b = FreshBool('eq')
            fs += [b == (v == v2)]
            equality_vars += [b]

    sneg.assert_exprs(slow_fml_simplify(And(fs)))

    output_file = open('output.smt2', 'w')
    output_file.write("%s" % solver_to_smtlib(s))
    output_file.close()

    output_file = open('output.neg.smt2', 'w')
    output_file.write("%s" % solver_to_smtlib(sneg))
    output_file.close()

    stop_watch('preprocessing', prep_start)

    FirstModel = True
    while True:
        t = time.clock()
        r = s.check()
        stop_watch('solve', t)
        if r == unsat:
            break

        if FirstModel:
          print 'first model took %s sec.' % (time.clock() - t)
          FirstModel = False

        tick('num_models')
        t = time.clock()
        (f, mask) = extract_and_generalize_sol(s.model(), vars, vars_blast,
                                               equality_vars, sneg)
        stop_watch('generalize', t)

        print print_soln(f, mask)
        s.assert_exprs(simplify((vars[0] & mask) != (f & mask)))

    stop_watch('total', prep_start)
    print_stats()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print '\nCaught Ctrl-C. Exiting..'
        print_stats()
