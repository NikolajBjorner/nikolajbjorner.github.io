#!/usr/bin/env python

'''
Copyright (c) 2013, Nuno Lopes
All rights reserved.
'''

import sys
sys.path.append('hassel')

import os, time, argparse
from headerspace.tf import TF
from headerspace.hs import byte_array_wildcard_to_mask_match_strings, byte_array_to_hs_string

links = set()

def get_router(port):
    return 100000 * (port / 100000)

def add_link(output_file, src, dst):
    global links
    src = get_router(src)
    dst = get_router(dst)
    name = src * 1000000 + dst
    if not name in links and src != dst :
        links = links | set([name])
        output_file.write("%d -> %d;\n" % (src,dst))

def generate_horn(rtr_name, input_path, output_file):
    tf = TF(1)
    input_file = os.path.join(input_path, rtr_name + ".tf")
    tf.load_object_from_file(input_file)

    for rule in tf.rules:
        for src in rule["in_ports"]:
            for dst in rule["out_ports"]:
                add_link(output_file, src, dst)

def main():
    rtr_names = [
                 "bbra_rtr",
                 "bbrb_rtr",
                 "boza_rtr",
                 "bozb_rtr",
                 "coza_rtr",
                 "cozb_rtr",
                 "goza_rtr",
                 "gozb_rtr",
                 "poza_rtr",
                 "pozb_rtr",
                 "roza_rtr",
                 "rozb_rtr",
                 "soza_rtr",
                 "sozb_rtr",
                 "yoza_rtr",
                 "yozb_rtr",
                 "backbone_topology"
                 ]
  
    parser = argparse.ArgumentParser(description='Convert tf files into .dot files (routers only)')
    parser.add_argument('--input_path', dest='input_path', required=False)
    parser.add_argument('--file', dest='file', required=False)
    args = parser.parse_args()
    
    if args.input_path != None:
        input_path = args.input_path
    else:
        input_path = ''

    if args.file != None:
        rtr_names = [args.file]
 
    output_file = open('output-routers.dot', 'w')
    output_file.write("digraph network {\n")

    for rtr_name in rtr_names:
        generate_horn(rtr_name, input_path, output_file)

    output_file.write("}\n")
    output_file.close()

if __name__ == "__main__":
    main()
